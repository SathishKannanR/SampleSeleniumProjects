package HolidayAction;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
//import org.testng.annotations.AfterMethod;
//import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AccountHierarchy {
	
		WebDriver driver;
		static ExtentReports report;
		static ExtentTest Test;
			
			@BeforeClass
			public void Launch() throws InterruptedException
			{
				report = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReportResults_AccountHierarchy_NextLevelWSA.html");
				Test = report.startTest("AccountHierarchy");
				WebDriverManager.chromedriver().setup(); 
				 driver=new ChromeDriver(); 
				 //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(80));
				 driver.get("https://localhost:8443/VolPayHubUI/#/login");
				 driver.manage().window().maximize();
				 driver.manage().deleteAllCookies(); 
				
				 driver.findElement(By.id("details-button")).click();
				 driver.findElement(By.linkText("Proceed to localhost (unsafe)")).click();
				WebElement txt= driver.findElement(By.className("form-control"));
				txt.clear();
				txt.sendKeys("adminuser");
				WebElement txt1= driver.findElement(By.name("password"));
				txt1.clear();
				txt1.sendKeys("Volpay@300");
				//Thread.sleep(3000);
				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
			    //Thread.sleep(5000);
			}
			
			@Test(dataProvider = "Login")
			public void AcctHierarchy(String AccountHierarchyCode, String PartyCode, String TopAccountNo, String Status, String EffectiveFromDate, 
					String EffectiveTillDate, String Level, String ParentAccountNo, String ChildAccountNo, String AccountGroupCode,
					String Level1, String ParentAccountNo1, String ChildAccountNo1, String AccountGroupCode1, String Flag) throws InterruptedException
			{
				if (Flag.equalsIgnoreCase("TC_AH_001"))
				{
				driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
		        Thread.sleep(2000);
		        driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
		        Thread.sleep(2000);
		        
		        driver.findElement(By.xpath("//span[contains(text(),'Account Hierarchy')]")).click();
		        driver.switchTo().frame(0);
		        //Thread.sleep(3000);
		        driver.findElement(By.xpath("//button[@class='btn-trans viewbtn' and @title='Add New']")).click();
		        //Thread.sleep(15000);
		        System.out.println("Add new Profile launched successfully");
		        
		        driver.findElement(By.xpath("//input[@id='Account Hierarchy Code']")).sendKeys(AccountHierarchyCode);
		        
		        driver.findElement(By.xpath("//span[@id='select2-Party Code-container']")).click();
		        WebElement We1=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
		        Thread.sleep(5000);
		        We1.sendKeys(PartyCode);
		        Thread.sleep(5000);
		    	We1.sendKeys(Keys.ENTER);
		    	
		    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Top Account No-container']")).click();
		    	Thread.sleep(5000);
		    	WebElement We2=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
		    	Thread.sleep(5000);
		        We2.sendKeys(TopAccountNo);
		        Thread.sleep(5000);
		    	We2.sendKeys(Keys.ENTER);
		    	
		    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
		    	Thread.sleep(5000);
		    	WebElement We3=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
		    	Thread.sleep(5000);
		        We3.sendKeys(Status);
		        Thread.sleep(5000);
		    	We3.sendKeys(Keys.ENTER);
		    	
		    	WebElement We4=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
		        We4.sendKeys(EffectiveFromDate);
		        We4.sendKeys(Keys.ENTER);
		        
		        //To select Level 2
		        driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Level-container']")).click();
		    	Thread.sleep(5000);
		        WebElement We5=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Level-results']"));
		    	Thread.sleep(5000);
		        We5.sendKeys(Level);
		        Thread.sleep(5000);
		    	We5.sendKeys(Keys.ENTER);
		    	
		    	// To select Parent Account Number
		    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Parent Account No-container']")).click();
		    	Thread.sleep(5000);
		    	WebElement We6=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
		    	Thread.sleep(5000);
		        We6.sendKeys(ParentAccountNo);
		        Thread.sleep(5000);
		    	We6.sendKeys(Keys.ENTER);
		    	
		    	// To select Child Account Number
		    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Child Account No-container']")).click();
		    	Thread.sleep(5000);
		    	WebElement We7=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
		    	Thread.sleep(5000);
		        We7.sendKeys(ChildAccountNo);
		        Thread.sleep(5000);
		    	We7.sendKeys(Keys.ENTER);
		    	
		    	driver.findElement(By.xpath("//a[@id='AddSection_$index']")).click();
		    	
		    	//To select Level3
		        Select se=new Select(driver.findElement(By.xpath("(//select[contains(@name, 'Level')])[2]")));
		        se.selectByVisibleText(Level1);
		        
		       driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Parent Account No_8_8-container']")).click();
		       Thread.sleep(5000);
		   	   WebElement We8=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
		   	   Thread.sleep(5000);
		       We8.sendKeys(ParentAccountNo1);
		       Thread.sleep(5000);
		   	   We8.sendKeys(Keys.ENTER);
		        
		   	   driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Child Account No_9_9_9_9-container']")).click();
		       Thread.sleep(5000);
		   	   WebElement We9=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
		   	   Thread.sleep(5000);
		       We9.sendKeys(ChildAccountNo1);
		       Thread.sleep(5000);
		   	   We9.sendKeys(Keys.ENTER);
		    	
		    	//To click on Add Hierarchy Button
		    	driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).click();
		    	 //Approvals
		        String result1= driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
			       System.out.println(result1);
			        if(result1.contains("AccountHierarchy pending approval for amendments."))
			        		{
			        	      
			        	      Thread.sleep(3000);
			        	      driver.get("https://200.200.200.203/SiteMinder/");
			        	      driver.manage().window().maximize();
			  				driver.manage().deleteAllCookies();
			  				//driver.findElement(By.id("details-button")).click();
			  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
			  				WebElement txt= driver.findElement(By.className("form-control"));
			  				txt.clear();
			  				txt.sendKeys("refdataapprover");
			  				WebElement txt1= driver.findElement(By.name("password"));
			  				txt1.clear();
			  				txt1.sendKeys("Volpay@300");
			  			    //Thread.sleep(3000);
			  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
			  				Thread.sleep(3000);
			  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
			  				Thread.sleep(3000);
			        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
			        	    Thread.sleep(3000);
			        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
			        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
			        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
			        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
			        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
			        	    Thread.sleep(3000);
			        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
			        	    System.out.println(Approver_Result);
			        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
			        	    {
			        	    	System.out.println("Entity has been Approved Successfully");
			        	    	Test.log(LogStatus.PASS, "AccountHierarchy has been Created Successfully for ThirdParty");
			        	    }
			        	    else
			        	    {
			        	    	System.out.println("Entity is not Approved, please check!!");
			        	    	Test.log(LogStatus.FAIL, "AccountHierarchy is not created");
			        	    }
			        		}
		    	
		    	/*System.out.println("Account Hierarchy has been created Successfully");
		    	Test.log(LogStatus.PASS, "Account Hierarchy has been created successfully for Next Level Scenario");*/
			}
				else
				{
					Test.log(LogStatus.FAIL, "Account Hierarchy is not created successfully");	
				}
			}
			@DataProvider(name="Login")
			public Object[][] getExcel() throws IOException
			{
				DataFormatter fr=new DataFormatter();
				FileInputStream fis = new FileInputStream("C:\\Users\\sathishkannan.r\\Automation\\TestDataDriven\\WorkorderData1.xlsx");
				   	XSSFWorkbook wb = new XSSFWorkbook(fis);
				   	XSSFSheet sh = wb.getSheetAt(3);
				   	XSSFRow row=sh.getRow(0);
				   	int rowCount=sh.getPhysicalNumberOfRows();
				   	System.out.println(rowCount);
				   	int colCount=row.getLastCellNum();
				   	System.out.println(colCount);
				   	Object data[][]= new Object[rowCount-1][colCount];
				   	for(int i=0;i<rowCount-1;i++)
				   	{
				   		row=sh.getRow(i+1);
				   		for(int j=0;j<colCount;j++)
				   		{
				   			XSSFCell cell=row.getCell(j);
				   			data[i][j]=fr.formatCellValue(cell);
				   			System.out.println(data[i][j]);
				   		}
				   	}
				   	wb.close();
					return data;
			}
			@AfterClass
			public void logout()
			{				
				report.endTest(Test);
				report.flush();
				System.out.println("Logout");
				driver.quit();
			}
	}
