package HolidayAction;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
//import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import GeneralFunction.CommonActions;

public class StandingInstructionProfile extends CommonActions {
		
	//WebDriver driver;
	static ExtentReports report;
	static ExtentTest Test;
		
		@BeforeMethod
		public void Launch() throws InterruptedException
		{
			report = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReportResults_SITemplate_ThirdParty_WSA.html");
			Test = report.startTest("StandingInstructionProfile");
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			driver.get("https://200.200.200.203/SiteMinder/");
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.findElement(By.id("details-button")).click();
			driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
			WebElement txt= driver.findElement(By.className("form-control"));
			txt.clear();
			txt.sendKeys("adminuser");
			WebElement txt1= driver.findElement(By.name("password"));
			txt1.clear();
			txt1.sendKeys("Volpay@300");
			//Thread.sleep(3000);
			driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
		    //Thread.sleep(5000);
		}
		
		@Test(dataProvider = "Login")
		public void StandingIInstructionTemplate(String TemplateName, String EntityStatusCode, String EffectiveFrom, String ProductsSupported,
				String MessageType, String AccountNumber, String ValueDate, String Currency, String Amount, String ReferenceForBeneficiary, String ClientId,
				String DebtorName, String AccountNumber1, String AccountName, String AccountCurrency, String AddressLine1, String AddressLine2,
				String City, String State, String PostalCode, String Country, String BankIdentifierType, String BankIdentificationCode,
				String AddressLine3, String AddressLine4, String City1, String State1, String PostalCode1, String Country1,
				String BankName,String BankIdentifierType1,String BankIdentificationNumber1,String BeneficiaryFinancialInstitutionName,
				String AddressLine5, String AddressLine6, String City2, String State2,String Country2,String PostalCode2, String ClientId1,
				String AccountNumber2, String AccountName1, String BeneficiaryName,String BeneficiaryAddressLine1, String BeneficiaryAddressLine2,String City3,
				String State3, String CountryCode,String PostalCode3,String AccountCurrency1,String RemittanceIdentifier,String OriginatorToBeneficiaryInformation,
				String BanktoBankInformation, String BankIdentifierType2,String BankIdentificationNumber2, String BeneficiaryFinancialInstitutionName1,String AddressLine7,
				String AddressLine8,String City4,String State4,String Country4,String PostalCode4) throws InterruptedException
		{
			Thread.sleep(2000);
			driver.findElement(By.xpath("(//span[contains(text(),' Dashboard')])[1]")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//span[contains(text(),'Standing Instruction Template')]")).click();
	        System.out.println("Standing Instruction Template Profile launched successfully");

	        driver.switchTo().frame(0);
	        Thread.sleep(3000);
	        driver.findElement(By.xpath("//button[@class='btn-trans viewbtn' and @title='Add New']")).click();
	        //Thread.sleep(15000);
	        System.out.println("Add new Profile launched successfully");
	        
	        driver.findElement(By.xpath("//input[@name='Template']")).sendKeys(TemplateName);
	        Thread.sleep(3000);
	        
	        /*Select st = new Select(driver.findElement(By.xpath("//select[@name='Status']")));
	        Thread.sleep(3000);
	        st.selectByVisibleText(EntityStatusCode);*/
	        
	        selectfunction("Status", EntityStatusCode);
	        
	        WebElement WE1=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
	        WE1.sendKeys(EffectiveFrom);
	        WE1.sendKeys(Keys.ENTER);
	        
	        /*Select se = new Select(driver.findElement(By.xpath("//select[@name='Product']")));
	        se.selectByVisibleText(ProductsSupported);*/
	        
	        selectfunction("Product", ProductsSupported);
	        
	        //To Select the Message Type
	        Select se1 = new Select(driver.findElement(By.xpath("//select[@name='MsgTp']")));
	        //se1.selectByIndex(4);
	        se1.selectByVisibleText(MessageType);
	        
	        WebElement Msg=se1.getFirstSelectedOption();
	        String MessageTpe=null;
	        MessageTpe=Msg.getText();
	        System.out.println(MessageTpe);
	        Thread.sleep(3000);
	        
	        try
	        {
	        if (MessageTpe.contains("CustomerCreditTransfer"))
	        {
	        Thread.sleep(3000);
	       /* Select se2 = new Select(driver.findElement(By.xpath("//select[@name='AccNo' and @ng-change='getPaymentTypeDetails(PmntInitnForm)']")));
	        Thread.sleep(3000);
	        se2.selectByValue(AccountNumber);*/
	        	
	        selectfunctionTemp("AccNo", AccountNumber);
	        
	        /*WebElement WE2=driver.findElement(By.xpath("//input[@name='ValueDate']"));
	        WE2.sendKeys("2021-09-29");
	        WE2.sendKeys(Keys.ENTER);*/
	        
	        /*Select se3 = new Select(driver.findElement(By.xpath("//select[@name='Ccy']")));
	        Thread.sleep(5000);
	        se3.selectByValue(Currency);*/
	        
	        selectfunctionTemp("Ccy", Currency);
	        

	        driver.findElement(By.xpath("//input[@name='Amt']")).sendKeys(Amount);
	        
	        //To open ordering Customer Section
	        //driver.findElement(By.xpath("//span[contains(text(), 'Ordering Customer')]")).click();        
	         
	        Thread.sleep(3000);
	        //To Open Ordering Bank Details Section
	        //driver.findElement(By.xpath("//span[contains(text(), 'Ordering Bank Details')]")).click();
	                
	        /*Select se4=new Select(driver.findElement(By.xpath("(//select[@name='BnfBkDtlsFinInstNm'])[2]")));
	        Thread.sleep(5000);
	        se4.selectByValue(BankIdentificationCode);*/
	        //Thread.sleep(5000);
	        //selectfunctionTemp("BnfBkDtlsFinInstNm", BankIdentificationCode);
	        
	       Thread.sleep(5000);
	      //To open Beneficiary Bank Details Section
	        driver.findElement(By.xpath("//span[contains(text(), 'Beneficiary Bank Details ')]")).click(); 
	        
	        //Beneficiary Bank Details Section
	        /*Select se5 = new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsBkIdNo']")));
	        Thread.sleep(3000);
	        se5.selectByValue(BankIdentificationNumber1);*/
	        
	        Thread.sleep(5000);
	        selectfunctionTemp("BnfBkDtlsBkIdNo", BankIdentificationNumber1);
	        
	        //Beneficiary Details
	        /*Select se6 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
	        Thread.sleep(5000);
	        se6.selectByValue(AccountNumber2);*/
	        
	        selectfunctionTemp("AccNo", AccountNumber2);
	        
	        //Submit Button
	        driver.findElement(By.xpath("//input[@class='btn btnStyle' and @value='Submit']")).click();
	        
	      //Approvals
	        String result1= driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
		       System.out.println(result1);
		        if(result1.contains("StandingInstructionTemplate pending approval for amendments."))
		        		{
		        	      
		        	      Thread.sleep(3000);
		        	      driver.get("https://200.200.200.203/SiteMinder/");
		        	      driver.manage().window().maximize();
		  				driver.manage().deleteAllCookies();
		  				//driver.findElement(By.id("details-button")).click();
		  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		  				WebElement txt= driver.findElement(By.className("form-control"));
		  				txt.clear();
		  				txt.sendKeys("refdataapprover");
		  				WebElement txt1= driver.findElement(By.name("password"));
		  				txt1.clear();
		  				txt1.sendKeys("Volpay@300");
		  			    //Thread.sleep(3000);
		  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
		  				Thread.sleep(3000);
		  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
		  				Thread.sleep(3000);
		        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
		        	    Thread.sleep(3000);
		        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
		        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
		        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
		        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
		        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
		        	    Thread.sleep(3000);
		        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
		        	    System.out.println(Approver_Result);
		        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
		        	    {
		        	    	System.out.println("Entity has been Approved Successfully");
		        	    	Test.log(LogStatus.PASS, "CT Template has been Created Successfully for ThirdParty");
		        	    }
		        	    else
		        	    {
		        	    	System.out.println("Entity is not Approved, please check!!");
		        	    	Test.log(LogStatus.FAIL, "CT Template has been Rejected/SI template is not created");
		        	    }
		        		}
	        
	        /*String act_res=driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
	        System.out.println(act_res);
	        if(act_res.contains("StandingInstructionTemplate successfully added"))
			{             
	            System.out.println("Template For Customer Credit Transfer has been created Successfully");
	            Test.log(LogStatus.PASS, "Template has been created successfully for CustomerCreditTransfer");
	        }
	        else
	        {
	        	System.out.println("Template is not created for CustomerCreditTransfer");
	        	Test.log(LogStatus.FAIL, "Template is not created for CustomerCreditTransfer");
	        }*/
	        
	        }
	        else if(MessageType.contains("CustomerRequestForPayment"))
	        {
	        	Thread.sleep(3000); 
	        	Select se2 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
	             se2.selectByValue(AccountNumber);
	             
	             /*WebElement WE2=driver.findElement(By.xpath("//input[@name='ValueDate']"));
	             WE2.sendKeys("2021-09-29");
	             WE2.sendKeys(Keys.ENTER);*/
	             
	             Select se3 = new Select(driver.findElement(By.xpath("//select[@name='Ccy']")));
	             se3.selectByValue(Currency);
	             

	             driver.findElement(By.xpath("//input[@name='Amt']")).sendKeys(Amount);             
	                           
	            //To open Debtor Details Section
	             driver.findElement(By.xpath("//span[contains(text(),'Debtor Details')]")).click();
	             
	             //To add Debtor Account Number
	             Select se4=new Select(driver.findElement(By.xpath("//select[@name='DbtrDtlsAccNo' and @ng-model='DbtrDtls.AccNo' ]")));
	             se4.selectByValue(AccountNumber1);
	             
	             Thread.sleep(3000);
	           //To open Debtor Bank Details Section
	             driver.findElement(By.xpath("//span[contains(text(),'Debtor Bank Details ')]")).click();
	             
	             Select se5=new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsFinInstNm' and @ng-model='DbtrBkDtls.BkIdCd' ]")));
	             Thread.sleep(5000);
	        	 se5.selectByValue(BankIdentificationCode);
	        	 
	        	 Thread.sleep(3000);
	        	//To open Beneficiary Bank Details
	        	 driver.findElement(By.xpath("//span[contains(text(),'Beneficiary Bank Details')]")).click();
	        	 
	        	 Select se6=new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsBkIdNo']")));
	        	 Thread.sleep(5000);
	        	 se6.selectByValue(BankIdentificationNumber1);
	        	 
	        	 Thread.sleep(3000);
	        	 //Submit Button
	             driver.findElement(By.xpath("(//input[@class='btn btnStyle'])[1]")).submit();
	             
	           //Approvals
	             String result1= driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
	     	       System.out.println(result1);
	     	        if(result1.contains("StandingInstructionTemplate pending approval for amendments."))
	     	        		{
	     	        	      
	     	        	      Thread.sleep(3000);
	     	        	      driver.get("https://200.200.200.203/SiteMinder/");
	     	        	      driver.manage().window().maximize();
	     	  				driver.manage().deleteAllCookies();
	     	  				//driver.findElement(By.id("details-button")).click();
	     	  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
	     	  				WebElement txt= driver.findElement(By.className("form-control"));
	     	  				txt.clear();
	     	  				txt.sendKeys("refdataapprover");
	     	  				WebElement txt1= driver.findElement(By.name("password"));
	     	  				txt1.clear();
	     	  				txt1.sendKeys("Volpay@300");
	     	  			    //Thread.sleep(3000);
	     	  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	     	  				Thread.sleep(3000);
	     	  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
	     	  				Thread.sleep(3000);
	     	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
	     	        	    Thread.sleep(3000);
	     	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
	     	        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
	     	        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
	     	        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
	     	        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
	     	        	    Thread.sleep(3000);
	     	        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
	     	        	    System.out.println(Approver_Result);
	     	        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
	     	        	    {
	     	        	    	System.out.println("Entity has been Approved Successfully");
	     	        	    	Test.log(LogStatus.PASS, "CT Template has been Created Successfully for ThirdParty");
	     	        	    }
	     	        	    else
	     	        	    {
	     	        	    	System.out.println("Entity is not Approved, please check!!");
	     	        	    	Test.log(LogStatus.FAIL, "CT Template has been Rejected/SI template is not created");
	     	        	    }
	     	        		}
	             
	             /*String act_res=driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
	            System.out.println(act_res);
	            
	            if(act_res.contains("StandingInstructionTemplate successfully added"))
	            		{             
	             System.out.println("Template For Customer Request For Payment has been created Successfully");
	             Test.log(LogStatus.PASS, "Template has been created successfully for Customer Request For Payment");
	        }
	            else
		        {
		        	System.out.println("Template is not created for CustomerRequestForPayment");
		        	Test.log(LogStatus.FAIL, "Template is not created for CustomerRequestForPayment");
		        }  */    
	   
		}
	        else if(MessageType.contains("BankRequestForPayment"))
	        {
	        	 Select se2 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
	             se2.selectByVisibleText("303230113(303230113)");
	             
	             /*WebElement WE2=driver.findElement(By.xpath("//input[@name='ValueDate']"));
	             WE2.sendKeys("2021-09-29");
	             WE2.sendKeys(Keys.ENTER);*/
	             
	             Select se3 = new Select(driver.findElement(By.xpath("//select[@name='Ccy']")));
	             se3.selectByVisibleText("USD(US)");
	             

	             driver.findElement(By.xpath("//input[@name='Amt']")).sendKeys("20000");             
	                           
	            //To open Debtor Details Section
	             driver.findElement(By.xpath("//span[contains(text(),'Debtor Details')]")).click();
	             
	             //To add Debtor Account Number
	             Select se4=new Select(driver.findElement(By.xpath("//select[@name='DbtrDtlsAccNo']")));
	             se4.selectByVisibleText("303230112(303230112)");
	             
	             Thread.sleep(3000);
	           //To open Debtor Bank Details Section
	             driver.findElement(By.xpath("//span[contains(text(),'Debtor Bank Details ')]")).click();
	             
	             Select se5=new Select(driver.findElement(By.xpath("(//select[@name='BnfBkDtlsFinInstNm'])[2]")));
	        	 se5.selectByVisibleText("021000018");
	        	 
	        	 Thread.sleep(3000);
	        	//To open Beneficiary Bank Details
	        	 driver.findElement(By.xpath("//span[contains(text(),'Beneficiary Bank Details')]")).click();
	        	 
	        	 Select se6=new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsBkIdNo']")));
	        	 se6.selectByVisibleText("211001234");
	        	 
	        	 Thread.sleep(3000);
	        	 
	        	 //Submit Button
	             driver.findElement(By.xpath("(//input[@class='btn btnStyle'])[1]")).submit();
	             
	           //Approvals
	             String result1= driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
	     	       System.out.println(result1);
	     	        if(result1.contains("StandingInstructionTemplate pending approval for amendments."))
	     	        		{
	     	        	      
	     	        	      Thread.sleep(3000);
	     	        	      driver.get("https://200.200.200.203/SiteMinder/");
	     	        	      driver.manage().window().maximize();
	     	  				driver.manage().deleteAllCookies();
	     	  				//driver.findElement(By.id("details-button")).click();
	     	  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
	     	  				WebElement txt= driver.findElement(By.className("form-control"));
	     	  				txt.clear();
	     	  				txt.sendKeys("refdataapprover");
	     	  				WebElement txt1= driver.findElement(By.name("password"));
	     	  				txt1.clear();
	     	  				txt1.sendKeys("Volpay@300");
	     	  			    //Thread.sleep(3000);
	     	  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	     	  				Thread.sleep(3000);
	     	  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
	     	  				Thread.sleep(3000);
	     	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
	     	        	    Thread.sleep(3000);
	     	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
	     	        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
	     	        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
	     	        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
	     	        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
	     	        	    Thread.sleep(3000);
	     	        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
	     	        	    System.out.println(Approver_Result);
	     	        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
	     	        	    {
	     	        	    	System.out.println("Entity has been Approved Successfully");
	     	        	    	Test.log(LogStatus.PASS, "CT Template has been Created Successfully for ThirdParty");
	     	        	    }
	     	        	    else
	     	        	    {
	     	        	    	System.out.println("Entity is not Approved, please check!!");
	     	        	    	Test.log(LogStatus.FAIL, "CT Template has been Rejected/SI template is not created");
	     	        	    }
	     	        		}
	        }
	             /*String act_res=driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
	            System.out.println(act_res);
	            
	            if(act_res.contains("StandingInstructionTemplate successfully added"))
	            		{             
	             System.out.println("Template For Bank Request For Payment has been created Successfully");	
	             Test.log(LogStatus.PASS, "Template has been created successfully for Bank Request For Payment");
	        }
	            else
	            {
	            	Test.log(LogStatus.FAIL, "Unable to create Template for Bank Request For Payment");
	            }
	        }*/
	        }      
	            catch(Exception e)
	        	{
	        	System.out.println(e.getMessage());
	        	}
	        
	        
		}
		@DataProvider(name="Login")
		public Object[][] getExcel() throws IOException
		{
			DataFormatter fr=new DataFormatter();
			FileInputStream fis = new FileInputStream("C:\\Users\\sathishkannan.r\\Automation\\TestDataDriven\\WorkorderData1.xlsx");
			   	XSSFWorkbook wb = new XSSFWorkbook(fis);
			   	XSSFSheet sh = wb.getSheetAt(6);
			   	XSSFRow row=sh.getRow(0);
			   	int rowCount=sh.getPhysicalNumberOfRows();
			   	System.out.println(rowCount);
			   	int colCount=row.getLastCellNum();
			   	System.out.println(colCount);
			   	Object data[][]= new Object[rowCount-1][colCount];
			   	for(int i=0;i<rowCount-1;i++)
			   	{
			   		row=sh.getRow(i+1);
			   		for(int j=0;j<colCount;j++)
			   		{
			   			XSSFCell cell=row.getCell(j);
			   			data[i][j]=fr.formatCellValue(cell);
			   			System.out.println(data[i][j]);
			   		}
			   	}
			   	wb.close();
				return data;
		}
		@AfterMethod
		public void logout()
		{
			report.endTest(Test);
			report.flush();
			System.out.println("Logout");
			driver.quit();
		}

}
