 package HolidayAction;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import GeneralFunction.CommonActions;

public class WorkorderCalender extends CommonActions {
	
	@BeforeClass
	public void Launch() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://200.200.200.203/SiteMinder/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		WebElement txt= driver.findElement(By.className("form-control"));
		txt.clear();
		txt.sendKeys("adminuser");
		WebElement txt1= driver.findElement(By.name("password"));
		txt1.clear();
		txt1.sendKeys("Volpay@300");
		//Thread.sleep(3000);
		driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	    //Thread.sleep(5000);
	}
		
	@Test
	public void calenderAction() throws InterruptedException
	{
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		String CurrentDay=new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date.getTime());
		System.out.println(CurrentDay);				
		
		driver.findElement(By.xpath("//span[contains(text(),'Reference Data')]")).click();
		driver.findElement(By.xpath("//span[contains(text(),' Bank Data')]")).click();
		driver.findElement(By.xpath("(//span[contains(text(),'Branch')])[1]")).click();
		driver.findElement(By.xpath("//span[contains(text(),' VBBI')]")).click();
		driver.findElement(By.xpath("(//div[@class='link d-inline ng-star-inserted'])[4]")).click();
			
		switch (CurrentDay) {
		case "Monday": 
		{	
			String Status=driver.findElement(By.xpath("//span[@id='Mon_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsTopLevel");
				//Workorder("WorkOrderNextLevel","WorkOrderNextLevel","GenerateSweep","WorkOrderNextLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsNextLevel");
			
			}
			break;
			
		}
		case "Tuesday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Tue_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsTopLevel");
				//Workorder("WorkOrderNextLevel","WorkOrderNextLevel","GenerateSweep","WorkOrderNextLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsNextLevel");
			
			}
			break;
		}
		case "Wednesday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Wed_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				//Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","AutoSweep");
				Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsTopLevel");
				//Workorder("WorkOrderNextLevel","WorkOrderNextLevel","GenerateSweep","WorkOrderNextLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsNextLevel");
			
			}
			break;
		}
		case "Thursday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Thu_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsTopLevel");
				//Workorder("WorkOrderNextLevel","WorkOrderNextLevel","GenerateSweep","WorkOrderNextLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsNextLevel");
			
			}
			break;
		}
		case "Friday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Fri_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsTopLevel");
				//Workorder("WorkOrderNextLevel","WorkOrderNextLevel","GenerateSweep","WorkOrderNextLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsNextLevel");
			
			}
			break;
		}
		case "Saturday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Sat_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsTopLevel");
				//Workorder("WorkOrderNextLevel","WorkOrderNextLevel","GenerateSweep","WorkOrderNextLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsNextLevel");
			
			}
			break;
		}
		case "Sunday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Sun_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsTopLevel");
				//Workorder("WorkOrderNextLevel","WorkOrderNextLevel","GenerateSweep","WorkOrderNextLevel","ACTIVE","2022-01-01","2022-01-30","Advance To Previous Business Day","VBBI","SweepsNextLevel");
			
			}
			break;		
		}
		default:
			System.out.println("Please provide a valid input");
		}
		}
	@AfterClass
	public void logout()
	{				
		/*report.endTest(Test);
		report.flush();*/
		System.out.println("Logout");
		driver.quit();
	}
	}

