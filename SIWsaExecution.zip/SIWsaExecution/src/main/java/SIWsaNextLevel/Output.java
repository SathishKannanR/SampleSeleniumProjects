package SIWsaNextLevel;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Output {
	
	WebDriver driver;
	static ExtentReports report;
	static ExtentTest Test;
		
		@BeforeClass
		public void Launch() throws InterruptedException
		{
			//report = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReportResults_AccountHierarchy.html");
			//Test = report.startTest("AccountHierarchy");
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			driver.get("https://200.200.200.203/SiteMinder/");
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.findElement(By.id("details-button")).click();
			driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
			WebElement txt= driver.findElement(By.className("form-control"));
			txt.clear();
			txt.sendKeys("adminuser");
			WebElement txt1= driver.findElement(By.name("password"));
			txt1.clear();
			txt1.sendKeys("Volpay@300");
			//Thread.sleep(3000);
			driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
		    //Thread.sleep(5000);
		}
		
		@Test
		public void SI_Output() throws InterruptedException
		{
			driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
			Thread.sleep(8000);
			driver.findElement(By.xpath("//span[contains(text(),'Generated Standing Instructions')]")).click();
			Thread.sleep(8000);
			/*String out=driver.findElement(By.xpath("(//span[contains(text(),' DEBULKED ')])[1]")).getText();*/
			driver.switchTo().frame(0);
			String Out=driver.findElement(By.xpath("(//span[@class='caption-subject bold ng-binding'])[1]")).getText();
			System.out.println(Out);
			if(Out.equals("DEBULKED"))
			{
				System.out.println("Instruction Has been 'Debulked' Successfully");
			}
			if(Out.equals("IN_PROGRESS"))
			{
				System.out.println("Instruction Status is IN_PROGRESS");
			}
			else if(Out.equals("WAITING_ACCOUNTBALANCELOOKUPRESPONSE"))
			{
				System.out.println("Instruction is in  WAITING_ACCOUNTBALANCELOOKUPRESPONSE");
			}
			else if(Out.equals("BUSINESSFAILURE"))
			{
				System.out.println("Instruction goes to Business Failure");
			}
			else if(Out.equals("CANCELLED"))
			{
				System.out.println("Instruction is Cancelled");
			}
			else
			{
				System.out.println("Instruction is Rejected");
			}
		}

}
