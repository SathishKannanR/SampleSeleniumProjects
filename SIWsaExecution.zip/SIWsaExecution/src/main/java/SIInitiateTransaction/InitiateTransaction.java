package SIInitiateTransaction;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import GeneralFunction.CommonActions;

//import GeneralFunction.CommonActions;

public class InitiateTransaction extends CommonActions {
	//WebDriver driver;
	static ExtentReports report;
	static ExtentTest Test;
		
		@BeforeMethod
		public void Launch() throws InterruptedException
		{
			report = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReportResults_SITemplate_ThirdParty_WSA.html");
			Test = report.startTest("StandingInstructionProfile");
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			driver.get("https://200.200.200.203/SiteMinder/");
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.findElement(By.id("details-button")).click();
			driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
			WebElement txt= driver.findElement(By.className("form-control"));
			txt.clear();
			txt.sendKeys("adminuser");
			WebElement txt1= driver.findElement(By.name("password"));
			txt1.clear();
			txt1.sendKeys("Volpay@300");
			//Thread.sleep(3000);
			driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
		    //Thread.sleep(5000);
		}
		
		@Test(dataProvider = "Login")
		public void IntiateTransaction(String TemplateName) throws InterruptedException
		{
			try
			{
			Thread.sleep(2000);
			driver.findElement(By.xpath("(//span[contains(text(),' Dashboard')])[1]")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//span[contains(text(),'Standing Instruction Initiate Transaction')]")).click();
	        System.out.println("Standing Instruction initiate Transaction launched successfully");
	        Thread.sleep(5000);
	        driver.switchTo().frame(0);
	        Select Se= new Select(driver.findElement(By.xpath("(//select[@name='Status'])[1]")));
	        Thread.sleep(3000);
	        Se.selectByValue(TemplateName);
	        driver.findElement(By.xpath("(//div[@class='panel-heading fileListStyle'])[3]")).click();
	        driver.findElement(By.xpath("(//div[@class='panel-heading fileListStyle'])[5]")).click();
	        driver.findElement(By.xpath("(//input[@class='btn btnStyle'])[1]")).submit();
	        System.out.println("SI initiated Successfully");
		}
			catch(Exception e)
        	{
        	System.out.println(e.getMessage());
        	}
		}
		@DataProvider(name="Login")
		public Object[][] getExcel() throws IOException
		{
			DataFormatter fr=new DataFormatter();
			FileInputStream fis = new FileInputStream("C:\\Users\\sathishkannan.r\\Automation\\TestDataDriven\\WorkorderData1.xlsx");
			   	XSSFWorkbook wb = new XSSFWorkbook(fis);
			   	XSSFSheet sh = wb.getSheetAt(11);
			   	XSSFRow row=sh.getRow(0);
			   	int rowCount=sh.getPhysicalNumberOfRows();
			   	System.out.println(rowCount);
			   	int colCount=row.getLastCellNum();
			   	System.out.println(colCount);
			   	Object data[][]= new Object[rowCount-1][colCount];
			   	for(int i=0;i<rowCount-1;i++)
			   	{
			   		row=sh.getRow(i+1);
			   		for(int j=0;j<colCount;j++)
			   		{
			   			XSSFCell cell=row.getCell(j);
			   			data[i][j]=fr.formatCellValue(cell);
			   			System.out.println(data[i][j]);
			   		}
			   	}
			   	wb.close();
				return data;
		}
		
		@AfterMethod
		public void logout()
		{
			//driver.quit();
			report.endTest(Test);
			report.flush();
			System.out.println("Logout");
		}

}
