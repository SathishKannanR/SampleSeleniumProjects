package SIWSATopLevel;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
//import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import GeneralFunction.CommonActions;

public class SchedulerProfile extends CommonActions {
	
		//WebDriver driver;
		static ExtentTest Test;
		static ExtentReports report;
		
	@BeforeClass
	public void Launch() throws InterruptedException
		{
		report = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReportResults_Scheduler_WSA.html");
	    Test = report.startTest("SchedulerProfile");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://200.200.200.203/SiteMinder/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		driver.findElement(By.name("username")).sendKeys("adminuser");
		driver.findElement(By.name("password")).sendKeys("Volpay@300");
		driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[@title='General Module' and @role='button']")).click();
		Thread.sleep(5000);
		}
	@Test(dataProvider = "Login")
	public void Sched(String SchedulerProfileCode, String SchedulerProfileName, String SchedulerProfileDesc, String TimeZone, String Status, String EffectiveFromDate,
		String Minutes, String Hours, String Days, String Day, String Months,
		String Years, String Flag) throws InterruptedException
		{
		if(Flag.equalsIgnoreCase("TC_SCH_002"))
		{
		driver.findElement(By.xpath("//span[contains(text(),'Standing Instruction Module')]")).click();
		//Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Scheduler')]")).click();
		//Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(text(),'Scheduler Profile')]")).click();
		//Thread.sleep(20000);
		System.out.println("Scheduler Profile launched successfully");
		//Thread.sleep(20000);
		driver.switchTo().frame(0);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@title='Add New']//i[@class='fa fa-plus-square']")).click();
		//Thread.sleep(15000);
		System.out.println("Add new Profile launched successfully");
		//Create Scheduler Profile
		driver.findElement(By.xpath("//input[@id='Scheduler Profile Code']")).sendKeys(SchedulerProfileCode);
		driver.findElement(By.xpath("//input[@id='Scheduler Profile Name']")).sendKeys(SchedulerProfileName);
		driver.findElement(By.xpath("//input[@id='Scheduler Profile Desc']")).sendKeys(SchedulerProfileDesc);
		driver.findElement(By.xpath("//span[@id='select2-Time Zone-container']")).click();
		Thread.sleep(3000);
		WebElement wb = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Time Zone-results']"));
		Thread.sleep(5000);
		wb.sendKeys(TimeZone);
		Thread.sleep(3000);
		wb.sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		System.out.println("Timezone selection success");
		
		driver.findElement(By.xpath("//span[@id='select2-Status-container']")).click();
		WebElement wb1=driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Status-results']"));
		wb1.sendKeys(Status);
		wb1.sendKeys(Keys.ENTER);
		System.out.println("Status has been updated successfully");

		//driver.findElement(By.xpath("//input[@id='Effective From Date']")).click();
		WebElement wb2=driver.findElement(By.xpath("//input[@id='Effective From Date']"));
		//wb2.click();
		wb2.sendKeys(EffectiveFromDate);
		wb2.sendKeys(Keys.ENTER);
		System.out.println("Effective from date has been updated successfully");

		//Thread.sleep(5000);
		/*driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[3]")).click();
		Thread.sleep(5000);
		WebElement mins = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @role='searchbox'])[7]"));
		Thread.sleep(5000);
		mins.sendKeys(Minutes);
		Thread.sleep(5000);
		mins.sendKeys(Keys.ENTER);
		System.out.println("Minutes has been updated successfully");*/
		
		selectfunction("Minutes", Minutes);
		System.out.println("Minutes has been updated successfully");


		/*Thread.sleep(5000);
		driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[5]")).click();
		Thread.sleep(5000);
		WebElement hrs = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @type='search'])[7]"));
		Thread.sleep(5000);
		hrs.sendKeys(Hours);
		Thread.sleep(5000);
		hrs.sendKeys(Keys.ENTER);*/
		
		selectfunction("Hours", Hours);
		System.out.println("Hours has been updated successfully");

		/*Thread.sleep(5000);
		driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[6]")).click();
		Thread.sleep(5000);
		WebElement day = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @type='search'])[7]"));
		Thread.sleep(5000);
		day.sendKeys(Days);
		Thread.sleep(5000);
		day.sendKeys(Keys.ENTER);*/
		
		/*Select se = new Select(driver.findElement(By.xpath("//select[@name='Days']")));
        se.selectByVisibleText("Every");*/
		
		
		/*Thread.sleep(5000);
		WebElement dys=driver.findElement(By.xpath("(//input[@class='select2-search__field' and @type='search' ])[3]"));
		Thread.sleep(5000);
		dys.sendKeys(Day);
		Thread.sleep(5000);
		dys.sendKeys(Keys.ENTER);*/
		
		selectfunction("Days", Days);
		System.out.println("day has been updated successfully");

		/*Thread.sleep(5000);
		driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[8]")).click();
		Thread.sleep(5000);
		WebElement mnt = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @type='search'])[7]"));
		Thread.sleep(5000);
		mnt.sendKeys(Months);
		Thread.sleep(5000);
		mnt.sendKeys(Keys.ENTER);*/
		
		selectfunction("Months", Months);
		System.out.println("Month has been updated successfully");

		/*Thread.sleep(5000);
		driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[9]")).click();
		Thread.sleep(5000);
		WebElement yrss = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @type='search'])[7]"));
		Thread.sleep(5000);
		yrss.sendKeys(Years);
		Thread.sleep(5000);
		yrss.sendKeys(Keys.ENTER);*/
		
		selectfunction("Years", Years);
		System.out.println("Months has been updated successfully");

		driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
		
		 //Approvals
        String result1= driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
	       System.out.println(result1);
	        if(result1.contains("SchedulerProfile pending approval for amendments."))
	        		{
	        	      
	        	      Thread.sleep(3000);
	        	      driver.get("https://200.200.200.203/SiteMinder/");
	        	      driver.manage().window().maximize();
	  				driver.manage().deleteAllCookies();
	  				//driver.findElement(By.id("details-button")).click();
	  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
	  				WebElement txt= driver.findElement(By.className("form-control"));
	  				txt.clear();
	  				txt.sendKeys("refdataapprover");
	  				WebElement txt1= driver.findElement(By.name("password"));
	  				txt1.clear();
	  				txt1.sendKeys("Volpay@300");
	  			    //Thread.sleep(3000);
	  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	  				Thread.sleep(3000);
	  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
	  				Thread.sleep(3000);
	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
	        	    Thread.sleep(3000);
	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
	        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
	        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
	        	    //driver.findElement(By.xpath("//button[contains(text(),'Reject')]")).click();
	        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
	        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
	        	    Thread.sleep(3000);
	        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
	        	    System.out.println(Approver_Result);
	        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
	        	    {
	        	    	System.out.println("Entity has been Approved Successfully");
	        	    	Test.log(LogStatus.PASS, "Scheduler Profile has been Created Successfully for ThirdParty");
	        	    }
	        	    else
	        	    {
	        	    	System.out.println("Entity is Rejected, please check!!");
	        	    	Test.log(LogStatus.FAIL, "Scheduler Profile has been Rejected");
	        	    }
	        		}
		
		/*Thread.sleep(3000);
		System.out.println("Scheduler Profile has been created successfully");
		Test.log(LogStatus.PASS, "Scheduler has been created Successfully");
		}*/
		 else
		   {
			Test.log(LogStatus.FAIL, "Scheduler profile not Created Properly");	
		    }
		}
		}

		@DataProvider(name="Login")
		public Object[][] getExcel() throws IOException
		{
		DataFormatter fr=new DataFormatter();
		FileInputStream fis = new FileInputStream("C:\\Users\\sathishkannan.r\\Automation\\TestDataDriven\\WorkorderData1.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheetAt(9);
		XSSFRow row=sh.getRow(0);
		int rowCount=sh.getPhysicalNumberOfRows();
		System.out.println(rowCount);
		int colCount=row.getLastCellNum();
		System.out.println(colCount);
		Object data[][]= new Object[rowCount-1][colCount];
		for(int i=0;i<rowCount-1;i++)
		{
		row=sh.getRow(i+1);
		for(int j=0;j<colCount;j++)
		{
		XSSFCell cell=row.getCell(j);
		data[i][j]=fr.formatCellValue(cell);
		System.out.println(data[i][j]);
		}
		}
		wb.close();
		return data;
		}
	@AfterClass
	public void logout()
		{
		report.endTest(Test);
		report.flush();
		//driver.quit();
		System.out.println("Logout");
		driver.quit();
		}
	}
