package SIWSATopLevel;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class GeneratedSI {
	
	WebDriver driver;
	static ExtentReports report;
	static ExtentTest Test;
	
	@BeforeClass
	public void Launch() throws InterruptedException
	{
		report = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReportResults_AccountHierarchy.html");
		Test = report.startTest("AccountHierarchy");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://200.200.200.203/SiteMinder/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		WebElement txt= driver.findElement(By.className("form-control"));
		txt.clear();
		txt.sendKeys("adminuser");
		WebElement txt1= driver.findElement(By.name("password"));
		txt1.clear();
		txt1.sendKeys("Volpay@300");
		//Thread.sleep(3000);
		driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	    //Thread.sleep(5000);
	}
	
	@Test
	public void GeneratedStandingInstruction() throws InterruptedException
	{
		driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),'Generated Standing Instructions')]")).click();
		Thread.sleep(2000);
		driver.switchTo().frame(0);
		driver.findElement(By.xpath("(//li[@class='bold cursorPointer ng-binding' and @style='font-size: 15px;padding-right: 7px;'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//i[@class='fa fa-asterisk']")).click();
		String Group_RefernceId=driver.findElement(By.xpath("//*[@id=\"tab2\"]/tbody/tr/td[2]")).getText();
		System.out.println(Group_RefernceId);
		
		String Accno =driver.findElement(By.xpath("(//a[@class='ng-binding ng-scope'])[1]")).getText();
		System.out.println(Accno);

		driver.get("http://admin:admin@200.200.200.203:8161/admin/queues.jsp");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.findElement(By.xpath("(//a[contains(text(),'Send To')])[9]")).click();
		driver.findElement(By.xpath("//textarea[@name='JMSText']")).clear();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementsByName('JMSText')[0].setAttribute('type', 'text');");
		driver.findElement(By.xpath("//textarea[@name='JMSText']")).clear();
				
		String Res="{\r\n"
				+ "\"Success\": {\r\n"
				+ "\"CrtTmStmp\": \"2020-09-29T17:52:12Z\",\r\n"
				+ "\"MsgReferenceID\": \"";
		String Res1= Group_RefernceId;
		String Res2= "\",\r\n";
		String Res3= "\"StsRsn\": \"SUCCESS\",\r\n"
				+ "\"StsRsnInf\": \"Positive response for payment hub to move ahead in processing\",\r\n"
				+ "\"AccountNumber\": \"";
		String Res4= Accno;
		String Res5= "\",\r\n ";
		String Res6= "\"Amount\": 101.89,\r\n"
				+ "\"AccountStatus\": \"Active\"\r\n"
				+ "}\r\n"
				+ "}";
		String Response=Res+Res1+Res2+Res3+Res4+Res5+Res6;    
	    System.out.println(Response);	  	
		driver.findElement(By.xpath("//textarea[@name='JMSText']")).sendKeys(Response);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		System.out.println("Response has been Submitted in activemq Successfully");
	}
		
	@AfterClass
	public void logout()
	{
		driver.quit();
		report.endTest(Test);
		report.flush();
		System.out.println("Logout");
	}
	}
	


