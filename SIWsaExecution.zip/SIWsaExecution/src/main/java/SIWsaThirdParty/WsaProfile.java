package SIWsaThirdParty;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
//import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class WsaProfile {

		WebDriver driver;
		static ExtentTest Test;
		static ExtentReports report;
		
	@BeforeClass
	public void Launch() throws InterruptedException
			{
		    report = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReportResults_WSA.html");
		    Test = report.startTest("WsaProfile");
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			driver.get("https://200.200.200.203/SiteMinder/");
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.findElement(By.id("details-button")).click();
			driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
			driver.findElement(By.name("username")).sendKeys("adminuser");
			driver.findElement(By.name("password")).sendKeys("Volpay@300");
			driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//a[@title='General Module' and @role='button']")).click();
			Thread.sleep(5000);
			}

	@Test(dataProvider = "Login")
	public void WSA(String WorkOrderSchedulerAssociationID, String WorkOrderSchedulerAssociationName, String WorkOrderSchedulerAssociationDescription, String WorkOrderProfileCode, String SchedulerProfileCode,
			String Status, String EffectiveFromDate, String Flag) throws InterruptedException
		{	
		if(Flag.equalsIgnoreCase("TC_WSA_001"))
		{
		driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(text(),' Scheduler')]")).click();
		driver.findElement(By.id("menu_WorkOrderSchedulerAssociation")).click();

		driver.switchTo().frame(0);
		driver.findElement(By.xpath("//button[@title='Add New' and @class='btn-trans viewbtn']")).click();
		driver.findElement(By.xpath("//input[@name='WSAId' and @id='Work Order Scheduler Association ID']")).sendKeys(WorkOrderSchedulerAssociationID);
		driver.findElement(By.xpath("//input[@name='WSAName' and @id='Work Order Scheduler Association Name']")).sendKeys(WorkOrderSchedulerAssociationName);
		driver.findElement(By.xpath("//input[@name='WSADesc' and @id='Work Order Scheduler Association Description']")).sendKeys(WorkOrderSchedulerAssociationDescription);
		System.out.println("Successfully WSA");

		driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Work Order Profile Code-container']")).click();
		WebElement wsa = driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Work Order Profile Code-results']"));
		Thread.sleep(5000);
		wsa.sendKeys(WorkOrderProfileCode);
		Thread.sleep(5000);
		wsa.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		System.out.println("Workorder Profile selected Successfully");
						
		
		driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Scheduler Profile Code-container']")).click();
		WebElement wsa1 = driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Scheduler Profile Code-results']"));
		Thread.sleep(5000);
		wsa1.sendKeys(SchedulerProfileCode);
		Thread.sleep(5000);
		wsa1.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
						
		/*driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
		WebElement WE = driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Status-results']"));
		WE.sendKeys(Status);
		WE.sendKeys(Keys.ENTER);
		Thread.sleep(2000);*/
		
		Thread.sleep(5000);
		Select se2 = new Select(driver.findElement(By.xpath("//select[@id='Status']")));
        se2.selectByVisibleText(Status);
        System.out.println("Status has been updated successfully");
		
		WebElement date = driver.findElement(By.xpath("//input[@name='EffectiveFromDate' and @id='Effective From Date']"));
		Thread.sleep(5000);
		date.sendKeys(EffectiveFromDate);
		//date.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='btn btnStyle clr' and @tooltip='Submit']")).click();
		 //Approvals
        String result1= driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
	       System.out.println(result1);
	        if(result1.contains("WorkOrderSchedulerAssociation pending approval for amendments."))
	        		{
	        	      
	        	      Thread.sleep(3000);
	        	      driver.get("https://200.200.200.203/SiteMinder/");
	        	      driver.manage().window().maximize();
	  				driver.manage().deleteAllCookies();
	  				//driver.findElement(By.id("details-button")).click();
	  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
	  				WebElement txt= driver.findElement(By.className("form-control"));
	  				txt.clear();
	  				txt.sendKeys("refdataapprover");
	  				WebElement txt1= driver.findElement(By.name("password"));
	  				txt1.clear();
	  				txt1.sendKeys("Volpay@300");
	  			    //Thread.sleep(3000);
	  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	  				Thread.sleep(3000);
	  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
	  				Thread.sleep(3000);
	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
	        	    Thread.sleep(3000);
	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
	        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
	        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
	        	  //driver.findElement(By.xpath("//button[contains(text(),'Reject')]")).click();
	        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
	        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
	        	    Thread.sleep(3000);
	        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
	        	    System.out.println(Approver_Result);
	        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
	        	    {
	        	    	System.out.println("Entity has been Approved Successfully");
	        	    	Test.log(LogStatus.PASS, "CT Template has been Created Successfully for ThirdParty");
	        	    }
	        	    else
	        	    {
	        	    	System.out.println("Entity is Rejected, please check!!");
	        	    	Test.log(LogStatus.FAIL, "CT Template has been Rejected/SI template is not created");
	        	    }
	        		}
		 /*Thread.sleep(3000);
		System.out.println("WSA Profile has been created successfully");
		Test.log(LogStatus.PASS, "WSA has been Created Successfully");*/
		
		}
		/*else
		{
			Test.log(LogStatus.FAIL, "WSA is not Created Successfully");
		}*/
		}

	@DataProvider(name="Login")
	public Object[][] getExcel() throws IOException
	{
	DataFormatter fr=new DataFormatter();
	FileInputStream fis = new FileInputStream("C:\\Users\\sathishkannan.r\\Automation\\TestDataDriven\\WorkorderData1.xlsx");
	XSSFWorkbook wb = new XSSFWorkbook(fis);
	XSSFSheet sh = wb.getSheetAt(10);
	XSSFRow row=sh.getRow(0);
	int rowCount=sh.getPhysicalNumberOfRows();
	System.out.println(rowCount);
	int colCount=row.getLastCellNum();
	System.out.println(colCount);
	Object data[][]= new Object[rowCount-1][colCount];
	for(int i=0;i<rowCount-1;i++)
	{
	row=sh.getRow(i+1);
	for(int j=0;j<colCount;j++)
	{
	XSSFCell cell=row.getCell(j);
	data[i][j]=fr.formatCellValue(cell);
	System.out.println(data[i][j]);
	}
	}
	wb.close();
	return data;
	}
	@AfterClass
	public void logout()
	{
	report.endTest(Test);
	report.flush();
	driver.quit();
	System.out.println("Logout");

	}
}
