package GeneralFunction;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class CommonActions {
	
	 public static WebDriver driver;
	 static ExtentReports report;
	 static ExtentTest Test;
		
	public static void selectfunction(String text, String value)
	{
		String selectbfrxpath = "//select[@name='";
		String selecttxt = text;
		String selectaftrxpath = "']";
		String actualxpath = selectbfrxpath + selecttxt + selectaftrxpath;
		Select selectdrpdwn = new Select(driver.findElement(By.xpath(actualxpath)));
		selectdrpdwn.selectByVisibleText(value);
		}
		
	public static void selectfunctionTemp(String text, String value)
	{
		String selectbfrxpath = "//select[@name='";
		String selecttxt = text;
		String selectaftrxpath = "']";
		String actualxpath = selectbfrxpath + selecttxt + selectaftrxpath;
		Select selectdrpdwn = new Select(driver.findElement(By.xpath(actualxpath)));
		selectdrpdwn.selectByValue(value);
		}
	
	
	
	
	public static void Workorder(String WorkOrderProfileCode, String WorkOrderName, String WorkOrderType, String WorkOrderDescription,
            String Status, String EffectiveFromDate, String EffectiveTillDate, 
            String HolidayAction, String BranchCode, String ParamValue) throws InterruptedException 
	{
				
		driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),' Scheduler')]")).click();
        driver.findElement(By.id("menu_WorkOrder")).click();
        
        driver.switchTo().frame(0);
        driver.findElement(By.xpath("//button[@title='Add New' and @class='btn-trans viewbtn']")).click();
        
        driver.findElement(By.xpath("//input[@name='WorkOrderId']")).sendKeys(WorkOrderProfileCode);
        driver.findElement(By.xpath("//input[@name='WorkOrderName']")).sendKeys(WorkOrderName);
        Thread.sleep(5000);
        
        driver.findElement(By.xpath("//span[@role='textbox' and @id='select2-Work Order Type-container']")).click();
        Thread.sleep(3000);
        WebElement wbservice = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Work Order Type-results']"));
        wbservice.sendKeys(WorkOrderType);
        wbservice.sendKeys(Keys.ENTER);
       
        driver.findElement(By.xpath("//input[@name='WorkOrderDesc']")).sendKeys(WorkOrderDescription);    
        
        driver.findElement(By.xpath("//span[@id='select2-Status-container']")).click();
        Thread.sleep(3000);
        WebElement WE = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Status-results']"));
        WE.sendKeys(Status);
        WE.sendKeys(Keys.ENTER);
        
        WebElement date = driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
        date.sendKeys(EffectiveFromDate);
        date.sendKeys(Keys.ENTER);
        System.out.println("Successfully enter user required date");
        
        driver.findElement(By.xpath("//span[@id='select2-Holiday Action-container']")).click();
        Thread.sleep(3000);
        WebElement WE1 = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Holiday Action-results']"));
        WE1.sendKeys(HolidayAction);
        WE1.sendKeys(Keys.ENTER);
        System.out.println("Successfully Advance To Previous Business Day");
        
        driver.findElement(By.xpath("//span[@id='select2-Branch Code-container']")).click();
        Thread.sleep(3000);
        WebElement WE2 = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Branch Code-results']"));
        Thread.sleep(3000);
        WE2.sendKeys(BranchCode);
        Thread.sleep(3000);
        WE2.sendKeys(Keys.ENTER);
        System.out.println("Successfully select branch code");
        
      
        WebElement WE3 = driver.findElement(By.xpath("//input[@class='select2-search__field']"));
        
        WE3.sendKeys(ParamValue);
        Thread.sleep(3000);
        //WE3.click();
        WE3.sendKeys(Keys.ENTER);
        WE3.click();
        
        WE3.sendKeys(Keys.TAB);
        	        
        driver.findElement(By.xpath("//span[contains(text(),'Add')]")).click();
        
        String result1= driver.findElement(By.xpath("//div[@id='statusBox' and @ng-repeat='alert in alerts']")).getText();
	       System.out.println(result1);
	        if(result1.contains("WorkOrder pending approval for amendments."))
	        		{
	        	      //System.out.println("Workorder Created Successfully");
	        	      Thread.sleep(3000);
	        	      driver.get("https://200.200.200.203/SiteMinder/");
	        	      driver.manage().window().maximize();
	  				driver.manage().deleteAllCookies();
	  				//driver.findElement(By.id("details-button")).click();
	  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
	  				WebElement txt= driver.findElement(By.className("form-control"));
	  				txt.clear();
	  				txt.sendKeys("refdataapprover");
	  				WebElement txt1= driver.findElement(By.name("password"));
	  				txt1.clear();
	  				txt1.sendKeys("Volpay@300");
	  			    //Thread.sleep(3000);
	  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	  				Thread.sleep(3000);
	  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
	  				Thread.sleep(3000);
	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
	        	    Thread.sleep(3000);
	        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
	        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
	        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
	        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
	        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
	        	    Thread.sleep(3000);
	        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
	        	    System.out.println(Approver_Result);
	        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
	        	    {
	        	    	System.out.println("Entity has been Approved Successfully");
	        	    	Test.log(LogStatus.PASS, "WorkOrder has been Created Successfully for ThirdParty");
	        	    }
	        	    else
	        	    {
	        	    	System.out.println("Entity is not Approved, please check!!");
	        	    	Test.log(LogStatus.FAIL, "WorkOrder has been Rejected");
	        	    }
	        		}       	

		
	}
	}

	

	
