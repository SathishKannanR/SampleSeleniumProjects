package ThirdParty;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
//import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Sweeps {
	WebDriver driver;
	static ExtentReports report;
	static ExtentTest Test;
	
	@BeforeClass
	public void Launch() throws InterruptedException
	{
		report = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReportResults_Sweeps_ThirdParty.html");
		Test = report.startTest("Sweeps");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://200.200.200.203/SiteMinder/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		WebElement txt= driver.findElement(By.className("form-control"));
		txt.clear();
		txt.sendKeys("adminuser");
		WebElement txt1= driver.findElement(By.name("password"));
		txt1.clear();
		txt1.sendKeys("Volpay@300");
		//Thread.sleep(3000);
		driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	    //Thread.sleep(5000);
	}
	@Test(dataProvider = "Login")
	public void Sweep(String SweepCode,String SweepDescription,String SweepType,String AccountHierarchyCode,String AccountNo,
			String AccountGroupCode,String CTTemplateID,String DDTemplateID,String OverridingTargetBalance,
			String OverridingTargetBalanceTolerance,String Notes,String Status,String EffectiveFromDate,String EffectiveTillDate,String Flag) throws InterruptedException
	{
		if (Flag.equalsIgnoreCase("TC_SW_001")) 
		{
		driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'Sweeps')]")).click();
        System.out.println("Sweeps Profile launched successfully");
        
        driver.switchTo().frame(0);
        //Thread.sleep(3000);
        driver.findElement(By.xpath("//button[@class='btn-trans viewbtn' and @title='Add New']")).click();
        //Thread.sleep(15000);
        System.out.println("Add new Profile launched successfully");
        
        driver.findElement(By.xpath("//input[@id='Sweep Code']")).sendKeys(SweepCode);
        driver.findElement(By.xpath("//input[@id='Sweep Description']")).sendKeys(SweepDescription);
        
        driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Sweep Type-container']")).click();
        WebElement WE1= driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Sweep Type-results']"));
        WE1.sendKeys(SweepType);
        WE1.sendKeys(Keys.ENTER);
        
        String actual_Result=driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Sweep Type-container']")).getText();
	    System.out.println(actual_Result);
	    
	    if(actual_Result.contains("THIRDPARTY"))
	    {
	    	 System.out.println("Sweep Type is Third Party, Hence Account Number and Template is Mandatory");
	    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account No-container']")).click();
	    	WebElement WE2=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account No-results']"));
	    	Thread.sleep(5000);
	    	WE2.sendKeys(AccountNo);
	    	Thread.sleep(5000);
	    	WE2.sendKeys(Keys.ENTER);
	    	
	    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-CTTemplate ID-container']")).click();
	    	WebElement WE3=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-CTTemplate ID-results']"));
	    	Thread.sleep(5000);
	    	WE3.sendKeys(CTTemplateID);
	    	Thread.sleep(5000);
	    	WE3.sendKeys(Keys.ENTER);
	    	
	    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-DDTemplate ID-container']")).click();
	    	WebElement WE4= driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-DDTemplate ID-results']"));
	    	Thread.sleep(5000);
	    	WE4.sendKeys(DDTemplateID);
	    	Thread.sleep(5000);
	    	WE4.sendKeys(Keys.ENTER);
	    	
	    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
	    	WebElement WE5=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Status-results']"));
	    	Thread.sleep(5000);
	    	WE5.sendKeys(Status);
	    	Thread.sleep(5000);
	    	WE5.sendKeys(Keys.ENTER);
	    	
	    	WebElement WE6=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
	        WE6.sendKeys(EffectiveFromDate);
	        WE6.sendKeys(Keys.ENTER);
	        
	        driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
	        //Thread.sleep(5000);
	        String result1= driver.findElement(By.xpath("//div[@id='statusBox' and @ng-repeat='alert in alerts']")).getText();
		       System.out.println(result1);
		        if(result1.contains("Sweeps pending approval for amendments."))
		        		{
		        	      //System.out.println("Workorder Created Successfully");
		        	      Thread.sleep(3000);
		        	      driver.get("https://200.200.200.203/SiteMinder/");
		        	      driver.manage().window().maximize();
		  				driver.manage().deleteAllCookies();
		  				//driver.findElement(By.id("details-button")).click();
		  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		  				WebElement txt= driver.findElement(By.className("form-control"));
		  				txt.clear();
		  				txt.sendKeys("refdataapprover");
		  				WebElement txt1= driver.findElement(By.name("password"));
		  				txt1.clear();
		  				txt1.sendKeys("Volpay@300");
		  			    //Thread.sleep(3000);
		  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
		  				Thread.sleep(3000);
		  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
		  				Thread.sleep(3000);
		        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
		        	    Thread.sleep(3000);
		        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
		        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
		        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
		        	  //driver.findElement(By.xpath("//button[contains(text(),'Reject')]")).click();
		        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
		        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
		        	    Thread.sleep(3000);
		        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
		        	    System.out.println(Approver_Result);
		        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
		        	    {
		        	    	System.out.println("Entity has been Approved Successfully");
		        	    	Test.log(LogStatus.PASS, "Sweeps has been Created Successfully for ThirdParty");
		        	    }
		        	    else
		        	    {
		        	    	System.out.println("Entity is Rejected, Please check!!");
		        	    	Test.log(LogStatus.FAIL, "Sweeps has been Rejected Successfully");
		        	    }
		        		}
	        
	        //System.out.println("Sweeps has been created Successfully for Third Party Case");
	        //Test.log(LogStatus.PASS, "Sweeps has been Created Successfully for ThirdParty");
	    }
	    else if(actual_Result.contains("TOPLEVEL"))
	    {
	    	 System.out.println("Sweep Type is TopLevel, Hence Template is not Mandatory, Account Hierarchy and Account Number is Mandatory");
	    	 
	    	 driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account Hierarchy Code-container']")).click();
	    	 WebElement WE7=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account Hierarchy Code-results']"));
	    	 Thread.sleep(5000);
	    	 WE7.sendKeys(AccountHierarchyCode);
	    	 Thread.sleep(5000);
	    	 WE7.sendKeys(Keys.ENTER);
	    	 
		     driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account No-container']")).click();
		     WebElement WE2=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account No-results']"));
		     Thread.sleep(5000);
		     WE2.sendKeys(AccountNo);
		     Thread.sleep(5000);
		     WE2.sendKeys(Keys.ENTER);
		     
		     driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
		    	WebElement WE5=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Status-results']"));
		    	Thread.sleep(5000);
		    	WE5.sendKeys(Status);
		    	Thread.sleep(5000);
		    	WE5.sendKeys(Keys.ENTER);
		    	
		    	WebElement WE6=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
		        WE6.sendKeys(EffectiveFromDate);
		        WE6.sendKeys(Keys.ENTER);
		        
		        driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
		        //Thread.sleep(5000);
		        String result1= driver.findElement(By.xpath("//div[@id='statusBox' and @ng-repeat='alert in alerts']")).getText();
			       System.out.println(result1);
			        if(result1.contains("Sweeps pending approval for amendments."))
			        		{
			        	      //System.out.println("Workorder Created Successfully");
			        	      Thread.sleep(3000);
			        	      driver.get("https://200.200.200.203/SiteMinder/");
			        	      driver.manage().window().maximize();
			  				driver.manage().deleteAllCookies();
			  				//driver.findElement(By.id("details-button")).click();
			  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
			  				WebElement txt= driver.findElement(By.className("form-control"));
			  				txt.clear();
			  				txt.sendKeys("refdataapprover");
			  				WebElement txt1= driver.findElement(By.name("password"));
			  				txt1.clear();
			  				txt1.sendKeys("Volpay@300");
			  			    //Thread.sleep(3000);
			  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
			  				Thread.sleep(3000);
			  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
			  				Thread.sleep(3000);
			        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
			        	    Thread.sleep(3000);
			        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
			        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
			        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
			        	  //driver.findElement(By.xpath("//button[contains(text(),'Reject')]")).click();
			        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
			        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
			        	    Thread.sleep(3000);
			        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
			        	    System.out.println(Approver_Result);
			        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
			        	    {
			        	    	System.out.println("Entity has been Approved Successfully");
			        	    	Test.log(LogStatus.PASS, "Sweeps has been Created Successfully for ThirdParty");
			        	    }
			        	    else
			        	    {
			        	    	System.out.println("Entity is Rejected, Please check!!");
			        	    	Test.log(LogStatus.FAIL, "Sweeps has been Rejected Successfully");
			        	    }
			        		}
		        //System.out.println("Sweeps has been created Successfully for Top Level Case");
		        //Test.log(LogStatus.PASS, "Sweeps has been Created Successfully for Top Level");
	    }
	    else
	    {
	    	System.out.println("Sweep Type is TopLevel, Hence Template is not Mandatory, Account Hierarchy and Account Number is Mandatory");
	    	 
	    	 driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account Hierarchy Code-container']")).click();
	    	 WebElement WE7=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account Hierarchy Code-results']"));
	    	 Thread.sleep(5000);
	    	 WE7.sendKeys(AccountHierarchyCode);
	    	 Thread.sleep(5000);
	    	 WE7.sendKeys(Keys.ENTER);
	    	 
		     driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account No-container']")).click();
		     WebElement WE2=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account No-results']"));
		     Thread.sleep(5000);
		     WE2.sendKeys(AccountNo);
		     Thread.sleep(5000);
		     WE2.sendKeys(Keys.ENTER);
		     
		     driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
		    	WebElement WE5=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Status-results']"));
		    	Thread.sleep(5000);
		    	WE5.sendKeys(Status);
		    	Thread.sleep(5000);
		    	WE5.sendKeys(Keys.ENTER);
		    	
		    	WebElement WE6=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
		        WE6.sendKeys(EffectiveFromDate);
		        WE6.sendKeys(Keys.ENTER);
		        
		        driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
		        String result1= driver.findElement(By.xpath("//div[@id='statusBox' and @ng-repeat='alert in alerts']")).getText();
			       System.out.println(result1);
			        if(result1.contains("Sweeps pending approval for amendments."))
			        		{
			        	      //System.out.println("Workorder Created Successfully");
			        	      Thread.sleep(3000);
			        	      driver.get("https://200.200.200.203/SiteMinder/");
			        	      driver.manage().window().maximize();
			  				driver.manage().deleteAllCookies();
			  				//driver.findElement(By.id("details-button")).click();
			  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
			  				WebElement txt= driver.findElement(By.className("form-control"));
			  				txt.clear();
			  				txt.sendKeys("refdataapprover");
			  				WebElement txt1= driver.findElement(By.name("password"));
			  				txt1.clear();
			  				txt1.sendKeys("Volpay@300");
			  			    //Thread.sleep(3000);
			  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
			  				Thread.sleep(3000);
			  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
			  				Thread.sleep(3000);
			        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
			        	    Thread.sleep(3000);
			        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
			        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
			        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
			        	  //driver.findElement(By.xpath("//button[contains(text(),'Reject')]")).click();
			        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
			        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
			        	    Thread.sleep(3000);
			        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
			        	    System.out.println(Approver_Result);
			        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
			        	    {
			        	    	System.out.println("Entity has been Approved Successfully");
			        	    	Test.log(LogStatus.PASS, "Sweeps has been Created Successfully for ThirdParty");
			        	    }
			        	    else
			        	    {
			        	    	System.out.println("Entity is Rejected, Please check!!");
			        	    	Test.log(LogStatus.FAIL, "Sweeps has been Rejected Successfully");
			        	    }
			        		}
		        /*Thread.sleep(5000);
		        System.out.println("Sweeps has been created Successfully for Next Level Case");	
		        Test.log(LogStatus.PASS, "Sweeps has been Created Successfully for NextLevel");*/
	}
	    
		}
		/*else
	    {
	    	System.out.println("Sweeps is not created Properly");	
	    	Test.log(LogStatus.FAIL, "Sweeps is not created Properly");
	    }*/
		
}
	@DataProvider(name="Login")
	public Object[][] getExcel() throws IOException
	{
		DataFormatter fr=new DataFormatter();
		FileInputStream fis = new FileInputStream("C:\\Users\\sathishkannan.r\\Automation\\TestDataDriven\\WorkorderData1.xlsx");
		   	XSSFWorkbook wb = new XSSFWorkbook(fis);
		   	XSSFSheet sh = wb.getSheetAt(2);
		   	XSSFRow row=sh.getRow(0);
		   	int rowCount=sh.getPhysicalNumberOfRows();
		   	System.out.println(rowCount);
		   	int colCount=row.getLastCellNum();
		   	System.out.println(colCount);
		   	Object data[][]= new Object[rowCount-1][colCount];
		   	for(int i=0;i<rowCount-1;i++)
		   	{
		   		row=sh.getRow(i+1);
		   		for(int j=0;j<colCount;j++)
		   		{
		   			XSSFCell cell=row.getCell(j);
		   			data[i][j]=fr.formatCellValue(cell);
		   			System.out.println(data[i][j]);
		   		}
		   	}
		   	wb.close();
			return data;
	}
	@AfterClass
	public void logout()
	{
		report.endTest(Test);
		report.flush();
		System.out.println("Logout");
		driver.quit();
	}
}

