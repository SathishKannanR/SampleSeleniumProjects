package NextLevel;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
//import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
public class WorkOrder {	
				
			WebDriver driver;
			static ExtentReports report;
			static ExtentTest Test;
			
			@BeforeClass
			public void Launch() throws InterruptedException
			{
				report = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReportResults_Workorder_NextLevel.html");
				Test = report.startTest("WorkOrder");
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
				driver=new ChromeDriver();
				driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
				driver.get("https://200.200.200.203/SiteMinder/");
				driver.manage().window().maximize();
				driver.manage().deleteAllCookies();
				driver.findElement(By.id("details-button")).click();
				driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
				WebElement txt= driver.findElement(By.className("form-control"));
				txt.clear();
				txt.sendKeys("adminuser");
				WebElement txt1= driver.findElement(By.name("password"));
				txt1.clear();
				txt1.sendKeys("Volpay@300");
				//Thread.sleep(3000);
				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
			    //Thread.sleep(5000);
			}
			@Test(dataProvider = "Login")
			public void Workorder(String WorkOrderProfileCode, String WorkOrderName, String WorkOrderType, String WorkOrderDescription,
	                String Status, String EffectiveFromDate, String EffectiveTillDate, String SkipNextExecution, 
	                String HolidayAction, String BranchCode, String ParamValue, String Flag) throws InterruptedException 
			{
				if (Flag.equalsIgnoreCase("TC_WO_004")) 
				{
				driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
		        Thread.sleep(2000);
		        driver.findElement(By.xpath("//span[contains(text(),' Scheduler')]")).click();
		        driver.findElement(By.id("menu_WorkOrder")).click();
		        
		        driver.switchTo().frame(0);
		        driver.findElement(By.xpath("//button[@title='Add New' and @class='btn-trans viewbtn']")).click();
		        
		        driver.findElement(By.xpath("//input[@name='WorkOrderId']")).sendKeys(WorkOrderProfileCode);
		        driver.findElement(By.xpath("//input[@name='WorkOrderName']")).sendKeys(WorkOrderName);
		        Thread.sleep(5000);
		        
		        driver.findElement(By.xpath("//span[@role='textbox' and @id='select2-Work Order Type-container']")).click();
		        Thread.sleep(3000);
		        WebElement wbservice = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Work Order Type-results']"));
		        wbservice.sendKeys(WorkOrderType);
		        wbservice.sendKeys(Keys.ENTER);
		       
		        driver.findElement(By.xpath("//input[@name='WorkOrderDesc']")).sendKeys(WorkOrderDescription);    
		        
		        driver.findElement(By.xpath("//span[@id='select2-Status-container']")).click();
		        Thread.sleep(3000);
		        WebElement WE = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Status-results']"));
		        WE.sendKeys(Status);
		        WE.sendKeys(Keys.ENTER);
		        
		        WebElement date = driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
		        date.sendKeys(EffectiveFromDate);
		        date.sendKeys(Keys.ENTER);
		        System.out.println("Successfully enter user required date");
		        
		        driver.findElement(By.xpath("//span[@id='select2-Holiday Action-container']")).click();
		        Thread.sleep(3000);
		        WebElement WE1 = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Holiday Action-results']"));
		        WE1.sendKeys(HolidayAction);
		        WE1.sendKeys(Keys.ENTER);
		        System.out.println("Successfully Advance To Previous Business Day");
		        
		        driver.findElement(By.xpath("//span[@id='select2-Branch Code-container']")).click();
		        Thread.sleep(3000);
		        WebElement WE2 = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Branch Code-results']"));
		        WE2.sendKeys(BranchCode);
		        WE2.sendKeys(Keys.ENTER);
		        System.out.println("Successfully select branch code");
		        
		      
		        WebElement WE3 = driver.findElement(By.xpath("//input[@class='select2-search__field']"));
		        
		        WE3.sendKeys(ParamValue);
		        Thread.sleep(3000);
		        //WE3.click();
		        WE3.sendKeys(Keys.ENTER);
		        WE3.click();
		        
		        WE3.sendKeys(Keys.TAB);
		        	        
		        driver.findElement(By.xpath("//span[contains(text(),'Add')]")).click();
		        /*Thread.sleep(3000);
		        Test.log(LogStatus.PASS, "Workorder has been created successfully");*/
		        String result1= driver.findElement(By.xpath("//div[@id='statusBox' and @ng-repeat='alert in alerts']")).getText();
			       System.out.println(result1);
			        if(result1.contains("WorkOrder pending approval for amendments."))
			        		{
			        	      //System.out.println("Workorder Created Successfully");
			        	      Thread.sleep(3000);
			        	      driver.get("https://200.200.200.203/SiteMinder/");
			        	      driver.manage().window().maximize();
			  				driver.manage().deleteAllCookies();
			  				//driver.findElement(By.id("details-button")).click();
			  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
			  				WebElement txt= driver.findElement(By.className("form-control"));
			  				txt.clear();
			  				txt.sendKeys("refdataapprover");
			  				WebElement txt1= driver.findElement(By.name("password"));
			  				txt1.clear();
			  				txt1.sendKeys("Volpay@300");
			  			    //Thread.sleep(3000);
			  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
			  				Thread.sleep(3000);
			  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
			  				Thread.sleep(3000);
			        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
			        	    Thread.sleep(3000);
			        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
			        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
			        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
			        	  //driver.findElement(By.xpath("//button[contains(text(),'Reject')]")).click();
			        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
			        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
			        	    Thread.sleep(3000);
			        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
			        	    System.out.println(Approver_Result);
			        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
			        	    {
			        	    	System.out.println("Entity has been Approved Successfully");
			        	    	Test.log(LogStatus.PASS, "Workorder has been Created Successfully for ThirdParty");
			        	    }
			        	    else
			        	    {
			        	    	System.out.println("Entity is Rejected, please check!!");
			        	    	Test.log(LogStatus.FAIL, "Workorder has been Rejected Successfully");
			        	    }
			        		}
				else
		        {
		        	//System.out.println("Workorder is not created Properly");
		        	Test.log(LogStatus.PASS, "Workorder has been created Successfully");
		        }
				}
			}
			@DataProvider(name="Login")
			public Object[][] getExcel() throws IOException
			{
				DataFormatter fr=new DataFormatter();
				FileInputStream fis = new FileInputStream("C:\\Users\\sathishkannan.r\\Automation\\TestDataDriven\\WorkorderData1.xlsx");
				   	XSSFWorkbook wb = new XSSFWorkbook(fis);
				   	XSSFSheet sh = wb.getSheetAt(1);
				   	XSSFRow row=sh.getRow(0);
				   	int rowCount=sh.getPhysicalNumberOfRows();
				   	System.out.println(rowCount);
				   	int colCount=row.getLastCellNum();
				   	System.out.println(colCount);
				   	Object data[][]= new Object[rowCount-1][colCount];
				   	for(int i=0;i<rowCount-1;i++)
				   	{
				   		row=sh.getRow(i+1);
				   		for(int j=0;j<colCount;j++)
				   		{
				   			XSSFCell cell=row.getCell(j);
				   			data[i][j]=fr.formatCellValue(cell);
				   			System.out.println(data[i][j]);
				   		}
				   	}
				   	wb.close();
					return data;
			}
			@AfterClass
			public void logout()
			{
				report.endTest(Test);
				report.flush();
				System.out.println("Logout");
				driver.quit();
			}	

}
