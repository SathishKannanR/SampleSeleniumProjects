package TestCode;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;


import GeneralFunction.CommonActions;

public class CalenderCode extends CommonActions{
	
	
	static ExtentReports report;
	static ExtentTest Test;
	//String Day;

	public static void main(String[] args) throws InterruptedException
	{
				
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		//System.out.println(new SimpleDateFormat("EE", Locale.ENGLISH).format(date.getTime()));
		String CurrentDay=new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date.getTime());
		System.out.println(CurrentDay);
		//System.out.println(new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date.getTime()));
		
		//To Launch SI
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://200.200.200.203/SiteMinder/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		driver.findElement(By.className("form-control")).sendKeys("adminuser");
		driver.findElement(By.name("password")).sendKeys("Volpay@300");
		driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
		//Thread.sleep(5000);
		System.out.println("login successfully");
		//Thread.sleep(8000);
		WebDriverWait wait = new WebDriverWait(driver, 12);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),' Dashboard')]")));
		driver.findElement(By.xpath("//span[contains(text(),' Dashboard')]")).click();
		//WebElement w1=driver.findElement(By.xpath("//span[contains(text(),' Dashboard')]"));
		//w1.click();
		//Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[contains(text(),'Reference Data')]")).click();
		driver.findElement(By.xpath("//span[contains(text(),' Bank Data')]")).click();
		driver.findElement(By.xpath("(//span[contains(text(),'Branch')])[1]")).click();
		driver.findElement(By.xpath("//span[contains(text(),' VBBI')]")).click();
		driver.findElement(By.xpath("(//div[@class='link d-inline ng-star-inserted'])[4]")).click();
			
		switch (CurrentDay) {
		case "Monday": 
		{	
			String Status=driver.findElement(By.xpath("//span[@id='Mon_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				//Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","SweepsTopLevel");
			Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
							
			}
			break;
			
		}
		case "Tuesday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Tue_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				//Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","SweepsTopLevel");
			Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
			}
			break;
		}
		case "Wednesday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Wed_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				
			//Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
			//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","SweepsTopLevel");
			Workorder("WorkOrderNextLevel","WorkOrderNextLevel","GenerateSweep","WorkOrderNextLevel","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","SweepsNextLevel");
				
			}
			break;
		}
		case "Thursday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Thr_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				//Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","SweepsTopLevel");
			Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
			
			}
			break;
		}
		case "Friday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Fri_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				//Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","SweepsTopLevel");
			Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
			}
			break;
		}
		case "Saturday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Sat_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				//Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","SweepsTopLevel");
			Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
			}
			break;
		}
		case "Sunday":
		{
			String Status=driver.findElement(By.xpath("//span[@id='Sun_readonly']")).getText();
			System.out.println(Status);
			if(Status.equals("WEEKLY OFF"))
			{
				//Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
				//Workorder("WorkOrderTopLevel","WorkOrderTopLevel","GenerateSweep","WorkOrderTopLevel","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","SweepsTopLevel");
			Workorder("WorkOrderThirdParty","WorkOrderThirdParty","GenerateSweep","WorkOrderThirdParty","ACTIVE","2022-01-01","2022-01-30","Postpone to Next Business Day","VB Bank USA","AutoSweep");
			}
			break;		
		}
		default:
			System.out.println("Please provide a valid input");
		}
		}
}

