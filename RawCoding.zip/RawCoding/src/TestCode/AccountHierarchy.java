package TestCode;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AccountHierarchy {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://200.200.200.203/SiteMinder/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		WebElement txt= driver.findElement(By.className("form-control"));
		txt.clear();
		txt.sendKeys("adminuser");
		WebElement txt1= driver.findElement(By.name("password"));
		txt1.clear();
		txt1.sendKeys("Volpay@300");
		//Thread.sleep(3000);
		driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	    //Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//span[contains(text(),'Account Hierarchy')]")).click();
        driver.switchTo().frame(0);
        //Thread.sleep(3000);
        driver.findElement(By.xpath("//button[@class='btn-trans viewbtn' and @title='Add New']")).click();
        //Thread.sleep(15000);
        System.out.println("Add new Profile launched successfully");
        
        driver.findElement(By.xpath("//input[@id='Account Hierarchy Code']")).sendKeys("AcctHyr1");
        
        driver.findElement(By.xpath("//span[@id='select2-Party Code-container']")).click();
        WebElement We1=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
        Thread.sleep(5000);
        We1.sendKeys("VB Bank");
        Thread.sleep(5000);
    	We1.sendKeys(Keys.ENTER);
    	
    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Top Account No-container']")).click();
    	Thread.sleep(5000);
    	WebElement We2=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
    	Thread.sleep(5000);
        We2.sendKeys("303230113");
        Thread.sleep(5000);
    	We2.sendKeys(Keys.ENTER);
    	
    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
    	WebElement We3=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
    	Thread.sleep(5000);
        We3.sendKeys("ACTIVE");
        //Thread.sleep(5000);
    	We3.sendKeys(Keys.ENTER);
    	
    	WebElement We4=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
        We4.sendKeys("2021-10-08");
        We4.sendKeys(Keys.ENTER);
        
        driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Level-container']")).click();
        WebElement We5=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Level-results']"));
    	Thread.sleep(5000);
        We5.sendKeys("2");
        //Thread.sleep(5000);
    	We5.sendKeys(Keys.ENTER);
    	
    	// To select Parent Account Number
    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Parent Account No-container']")).click();
    	Thread.sleep(3000);
    	WebElement We6=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
    	Thread.sleep(5000);
        We6.sendKeys("303230113");
        Thread.sleep(5000);
    	We6.sendKeys(Keys.ENTER);
    	
    	// To select Child Account Number
    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Child Account No-container']")).click();
    	Thread.sleep(5000);
    	WebElement We7=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
    	Thread.sleep(5000);
        We7.sendKeys("2873198732");
        //Thread.sleep(5000);
    	We7.sendKeys(Keys.ENTER);
    	
    	driver.findElement(By.xpath("//a[@id='AddSection_$index']")).click();
    	
    	//To select Level3
         Select se=new Select(driver.findElement(By.xpath("(//select[contains(@name, 'Level')])[2]")));
         se.selectByVisibleText("3");
         
        driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Parent Account No_8_8-container']")).click();
        Thread.sleep(5000);
    	WebElement We8=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
    	Thread.sleep(5000);
        We8.sendKeys("2873198732");
        //Thread.sleep(5000);
    	We8.sendKeys(Keys.ENTER);
         
    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Child Account No_9_9_9_9-container']")).click();
        Thread.sleep(5000);
    	WebElement We9=driver.findElement(By.xpath("//input[@class='select2-search__field']"));
    	Thread.sleep(5000);
        We9.sendKeys("2873198731");
        //Thread.sleep(5000);
    	We9.sendKeys(Keys.ENTER);
         
    	//To click on Add Hierarchy Button
    	driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).click();
	}

}
