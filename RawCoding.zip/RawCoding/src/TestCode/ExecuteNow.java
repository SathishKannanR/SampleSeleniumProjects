package TestCode;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExecuteNow {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;
		try
		{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://200.200.200.203/SiteMinder/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		WebElement txt= driver.findElement(By.className("form-control"));
		txt.clear();
		txt.sendKeys("adminuser");
		WebElement txt1= driver.findElement(By.name("password"));
		txt1.clear();
		txt1.sendKeys("Volpay@300");
		//Thread.sleep(3000);
		driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	    //Thread.sleep(5000);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[contains(text(),' Dashboard')])[1]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'Scheduler')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'Execute Now')]")).click();
        Thread.sleep(5000);
        driver.switchTo().frame(0);
        /*WebDriverWait wait = new WebDriverWait(driver, 10);
        WebElement Category_Body = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[@class='select2-selection__rendered'])[1]")));
        Category_Body.click();*/
        driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[1]")).click();
        //driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[1]"));
        WebElement WE1=driver.findElement(By.xpath("(//input[@class='select2-search__field'])[2]"));
        Thread.sleep(2000);
        WE1.sendKeys("NewThirdPartyCTWO");
        Thread.sleep(2000);
        WE1.sendKeys(Keys.ENTER);
        
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
        System.out.println("Instruction has been initiated successfully via Execute Now");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
