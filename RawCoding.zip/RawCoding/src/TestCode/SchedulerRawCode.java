package TestCode;

import java.util.concurrent.TimeUnit;
//import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.support.ui.Select;

public class SchedulerRawCode {

public static void main(String[] args) throws InterruptedException {
System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
WebDriver driver = new ChromeDriver();
driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
driver.get("https://200.200.200.203/SiteMinder/");
driver.manage().window().maximize();
driver.manage().deleteAllCookies();

driver.findElement(By.id("details-button")).click();
driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
driver.findElement(By.className("form-control")).sendKeys("adminuser");
driver.findElement(By.name("password")).sendKeys("Volpay@300");
driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
//Thread.sleep(5000);
System.out.println("login successfully");
//Thread.sleep(8000);
WebDriverWait wait = new WebDriverWait(driver, 12);
wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),' Dashboard')]")));
driver.findElement(By.xpath("//span[contains(text(),' Dashboard')]")).click();
//WebElement w1=driver.findElement(By.xpath("//span[contains(text(),' Dashboard')]"));
//w1.click();
//Thread.sleep(5000);
driver.findElement(By.xpath("//span[contains(text(),'Standing Instruction Module')]")).click();
//Thread.sleep(3000);
driver.findElement(By.xpath("//span[contains(text(),'Scheduler')]")).click();
//Thread.sleep(3000);
driver.findElement(By.xpath("//span[contains(text(),'Scheduler Profile')]")).click();
//Thread.sleep(20000);
System.out.println("Scheduler Profile launched successfully");
//Thread.sleep(20000);
driver.switchTo().frame(0);
Thread.sleep(3000);
driver.findElement(By.xpath("//button[@title='Add New']//i[@class='fa fa-plus-square']")).click();
//Thread.sleep(15000);
System.out.println("Add new Profile launched successfully");
//Create Scheduler Profile

driver.findElement(By.xpath("//input[@id='Scheduler Profile Code']")).sendKeys("AutoSch");
driver.findElement(By.xpath("//input[@id='Scheduler Profile Name']")).sendKeys("AutoSch");
driver.findElement(By.xpath("//input[@id='Scheduler Profile Desc']")).sendKeys("AutoSch");
//WebElement we= driver.findElement(By.xpath("//span[@id='select2-Time Zone-container']"));
//we.click();
//Select se= new Select(we);
//se.selectByVisibleText("Africa/Abidjan");
//se.selectByIndex(3);*/
//click("//span[@id='select2-Time Zone-container");
driver.findElement(By.xpath("//span[@id='select2-Time Zone-container']")).click();
Thread.sleep(3000);
WebElement wb = driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Time Zone-results']"));
Thread.sleep(5000);
wb.sendKeys("PST");
Thread.sleep(3000);
wb.sendKeys(Keys.ENTER);
Thread.sleep(3000);
System.out.println("Timezone selection success");

driver.findElement(By.xpath("//span[@id='select2-Status-container']")).click();
WebElement wb1=driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Status-results']"));
wb1.sendKeys("ACTIVE");
wb1.sendKeys(Keys.ENTER);
System.out.println("Status has been updated successfully");

//driver.findElement(By.xpath("//input[@id='Effective From Date']")).click();
WebElement wb2=driver.findElement(By.xpath("//input[@id='Effective From Date']"));
//wb2.click();
wb2.sendKeys("2021-06-09");
wb2.sendKeys(Keys.ENTER);
System.out.println("Effective from date has been updated successfully");

Thread.sleep(5000);
driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[3]")).click();
Thread.sleep(5000);
WebElement wb3 = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @role='searchbox'])[7]"));
Thread.sleep(5000);
wb3.sendKeys("Every");
Thread.sleep(5000);
wb3.sendKeys(Keys.ENTER);
System.out.println("Minutes has been updated successfully");


Thread.sleep(5000);
driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[5]")).click();
Thread.sleep(5000);
WebElement hrs = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @type='search'])[7]"));
Thread.sleep(5000);
hrs.sendKeys("Every");
Thread.sleep(5000);
hrs.sendKeys(Keys.ENTER);
System.out.println("Hours has been updated successfully");


/*driver.findElement(By.xpath("(//button[@type='submit' and @class='btn btnStyle clr']")).click();
Thread.sleep(5000);*/

Thread.sleep(5000);
driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[6]")).click();
Thread.sleep(5000);
WebElement dys = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @type='search'])[7]"));
Thread.sleep(5000);
dys.sendKeys("Every ");
Thread.sleep(5000);
dys.sendKeys(Keys.ENTER);
System.out.println("Days has been updated successfully");

Thread.sleep(5000);
driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[8]")).click();
Thread.sleep(5000);
WebElement mnt = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @type='search'])[7]"));
Thread.sleep(5000);
mnt.sendKeys("Every");
Thread.sleep(5000);
mnt.sendKeys(Keys.ENTER);
System.out.println("Month has been updated successfully");

Thread.sleep(5000);
driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[9]")).click();
Thread.sleep(5000);
WebElement wsa9 = driver.findElement(By.xpath("(//input[@class='select2-search__field' and @type='search'])[7]"));
Thread.sleep(5000);
wsa9.sendKeys("Every");
Thread.sleep(5000);
wsa9.sendKeys(Keys.ENTER);
System.out.println("Months has been updated successfully");

driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
System.out.println("Scheduler Profile has been created successfully");

}
}


