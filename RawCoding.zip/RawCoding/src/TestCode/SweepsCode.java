package TestCode;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SweepsCode {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        driver.get("https://200.200.200.203/SiteMinder/");
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();        
        driver.findElement(By.id("details-button")).click();
        driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
        driver.findElement(By.className("form-control")).sendKeys("adminuser");
        driver.findElement(By.name("password")).sendKeys("Volpay@300");
        driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
        System.out.println("login successfully");
        
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'Sweeps')]")).click();
        System.out.println("Sweeps Profile launched successfully");
        
        driver.switchTo().frame(0);
        //Thread.sleep(3000);
        driver.findElement(By.xpath("//button[@class='btn-trans viewbtn' and @title='Add New']")).click();
        //Thread.sleep(15000);
        System.out.println("Add new Profile launched successfully");
        
        driver.findElement(By.xpath("//input[@id='Sweep Code']")).sendKeys("TestSweep");
        driver.findElement(By.xpath("//input[@id='Sweep Description']")).sendKeys("TestSweep");
        
        driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Sweep Type-container']")).click();
        WebElement WE1= driver.findElement(By.xpath("//input[@type='search' and @aria-controls='select2-Sweep Type-results']"));
        WE1.sendKeys("THIRDPARTY");
        WE1.sendKeys(Keys.ENTER);
        
        String actual_Result=driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Sweep Type-container']")).getText();
	    System.out.println(actual_Result);
	    
	    if(actual_Result.contains("THIRDPARTY"))
	    {
	    	 System.out.println("Sweep Type is Third Party, Hence Account Number and Template is Mandatory");
	    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account No-container']")).click();
	    	WebElement WE2=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account No-results']"));
	    	Thread.sleep(5000);
	    	WE2.sendKeys("2873198732");
	    	Thread.sleep(5000);
	    	WE2.sendKeys(Keys.ENTER);
	    	
	    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-CTTemplate ID-container']")).click();
	    	WebElement WE3=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-CTTemplate ID-results']"));
	    	Thread.sleep(5000);
	    	WE3.sendKeys("NewCTThirdParty");
	    	Thread.sleep(5000);
	    	WE3.sendKeys(Keys.ENTER);
	    	
	    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-DDTemplate ID-container']")).click();
	    	WebElement WE4= driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-DDTemplate ID-results']"));
	    	Thread.sleep(5000);
	    	WE4.sendKeys("NewDDThirdParty1");
	    	Thread.sleep(5000);
	    	WE4.sendKeys(Keys.ENTER);
	    	
	    	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
	    	WebElement WE5=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Status-results']"));
	    	Thread.sleep(5000);
	    	WE5.sendKeys("ACTIVE");
	    	Thread.sleep(5000);
	    	WE5.sendKeys(Keys.ENTER);
	    	
	    	WebElement WE6=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
	        WE6.sendKeys("2021-12-20");
	        WE6.sendKeys(Keys.ENTER);
	        
	        driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
	        //Thread.sleep(5000);
	        //System.out.println("Sweeps has been created Successfully for Third Party Case");
	        String actual_result= driver.findElement(By.xpath("//div[@id='statusBox' and @ng-repeat='alert in alerts']")).getText();
		       System.out.println(actual_result);
		        if(actual_result.contains("Sweeps pending approval for amendments."))
		        		{
		        	      //System.out.println("Workorder Created Successfully");
		        	      Thread.sleep(3000);
		        	      driver.get("https://200.200.200.203/SiteMinder/");
		        	      driver.manage().window().maximize();
		  				driver.manage().deleteAllCookies();
		  				//driver.findElement(By.id("details-button")).click();
		  				//driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		  				WebElement txt= driver.findElement(By.className("form-control"));
		  				txt.clear();
		  				txt.sendKeys("refdataapprover");
		  				WebElement txt1= driver.findElement(By.name("password"));
		  				txt1.clear();
		  				txt1.sendKeys("Volpay@300");
		  			    //Thread.sleep(3000);
		  				driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
		  				Thread.sleep(3000);
		  				driver.findElement(By.xpath("//span[contains(text(),'System Module')]")).click();
		  				Thread.sleep(3000);
		        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Menu')]")).click();
		        	    Thread.sleep(3000);
		        	    driver.findElement(By.xpath("//span[contains(text(),'Approval Details')]")).click();
		        	    driver.findElement(By.xpath("(//span[contains(text(), ' adminuser ')] )")).click();
		        	    driver.findElement(By.xpath("//button[contains(text(),'Approve')]")).click();
		        	    //driver.findElement(By.xpath("//input[@id='IdTp']")).sendKeys("Approved");
		        	    driver.findElement(By.xpath("//button[contains(text(),' Submit ')]")).click();
		        	    Thread.sleep(3000);
		        	    String Approver_Result=driver.findElement(By.xpath("(//div[@class='w-100 bold animated fadeIn alert alert-success'])[2]")).getText();
		        	    System.out.println(Approver_Result);
		        	    if(Approver_Result.contains("Approved sucessfully..All Level of approval are done"))
		        	    {
		        	    	System.out.println("Entity has been Approved Successfully");
		        	    }
		        	    else
		        	    {
		        	    	System.out.println("Entity is not Approved, please check!!");
		        	    }
		        	    //and (//span[contains(text(),' WAITING_FOR_APPROVAL ')]) and  (//span[contains(text(),'  CREATION ')])")).click();
		        	    //System.out.println(Approval_Selection);
		        	    //if(Approval_Selection=='True')
		        	            	    	
		        	    
		        	 }
		       /* else
		        {
		        	System.out.println("Workorder is not created Properly");
		        	Test.log(LogStatus.FAIL, "Workorder is not created Properly");
		        }*/
	        
	    }
	    else if(actual_Result.contains("TOPLEVEL"))
	    {
	    	 System.out.println("Sweep Type is TopLevel, Hence Template is not Mandatory, Account Hierarchy and Account Number is Mandatory");
	    	 
	    	 driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account Hierarchy Code-container']")).click();
	    	 WebElement WE7=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account Hierarchy Code-results']"));
	    	 Thread.sleep(5000);
	    	 WE7.sendKeys("AccHy");
	    	 Thread.sleep(5000);
	    	 WE7.sendKeys(Keys.ENTER);
	    	 
		     driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account No-container']")).click();
		     WebElement WE2=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account No-results']"));
		     Thread.sleep(5000);
		     WE2.sendKeys("303230113");
		     Thread.sleep(5000);
		     WE2.sendKeys(Keys.ENTER);
		     
		     driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
		    	WebElement WE5=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Status-results']"));
		    	Thread.sleep(5000);
		    	WE5.sendKeys("ACTIVE");
		    	Thread.sleep(5000);
		    	WE5.sendKeys(Keys.ENTER);
		    	
		    	WebElement WE6=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
		        WE6.sendKeys("2021-09-21");
		        WE6.sendKeys(Keys.ENTER);
		        
		        driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
		        Thread.sleep(5000);
		        System.out.println("Sweeps has been created Successfully for Top Level Case");
	    }
	    else
	    {
	    	System.out.println("Sweep Type is TopLevel, Hence Template is not Mandatory, Account Hierarchy and Account Number is Mandatory");
	    	 
	    	 driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account Hierarchy Code-container']")).click();
	    	 WebElement WE7=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account Hierarchy Code-results']"));
	    	 Thread.sleep(5000);
	    	 WE7.sendKeys("AccHyNext");
	    	 Thread.sleep(5000);
	    	 WE7.sendKeys(Keys.ENTER);
	    	 
		     driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account No-container']")).click();
		     WebElement WE2=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account No-results']"));
		     Thread.sleep(5000);
		     WE2.sendKeys("303230110");
		     Thread.sleep(5000);
		     WE2.sendKeys(Keys.ENTER);
		     
		     driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
		    	WebElement WE5=driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Status-results']"));
		    	Thread.sleep(5000);
		    	WE5.sendKeys("ACTIVE");
		    	Thread.sleep(5000);
		    	WE5.sendKeys(Keys.ENTER);
		    	
		    	WebElement WE6=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
		        WE6.sendKeys("2021-09-21");
		        WE6.sendKeys(Keys.ENTER);
		        
		        driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
		        Thread.sleep(5000);
		        System.out.println("Sweeps has been created Successfully for Next Level Case");	
	    }
	    //driver.close();
	}
	

}
