package Testing;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExecuteNow {
WebDriver driver;
	
	@BeforeMethod
	public void Launch() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://200.200.200.203/SiteMinder/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		WebElement txt= driver.findElement(By.className("form-control"));
		txt.clear();
		txt.sendKeys("adminuser");
		WebElement txt1= driver.findElement(By.name("password"));
		txt1.clear();
		txt1.sendKeys("Volpay@300");
		//Thread.sleep(3000);
		driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	    //Thread.sleep(5000);
	}
	@Test(dataProvider = "Login")
	public void ExcuteNow(String Workorder) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[contains(text(),' Dashboard')])[1]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'Scheduler')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'Execute Now')]")).click();
        Thread.sleep(5000);
        driver.switchTo().frame(0);
        driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[1]")).click();
        //driver.findElement(By.xpath("(//span[@class='select2-selection__rendered'])[1]"));
        WebElement WE1=driver.findElement(By.xpath("(//input[@class='select2-search__field'])[2]"));
        Thread.sleep(2000);
        WE1.sendKeys(Workorder);
        Thread.sleep(2000);
        WE1.sendKeys(Keys.ENTER);
        
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//button[@class='btn btnStyle clr'])[1]")).submit();
        System.out.println("Instruction has been initiated successfully via Execute Now");
        
	}
	@DataProvider(name="Login")
	public Object[][] getExcel() throws IOException
	{
		DataFormatter fr=new DataFormatter();
		FileInputStream fis = new FileInputStream("C:\\Users\\sathishkannan.r\\Automation\\TestDataDriven\\WorkorderData1.xlsx");
		   	XSSFWorkbook wb = new XSSFWorkbook(fis);
		   	XSSFSheet sh = wb.getSheetAt(7);
		   	XSSFRow row=sh.getRow(0);
		   	int rowCount=sh.getPhysicalNumberOfRows();
		   	System.out.println(rowCount);
		   	int colCount=row.getLastCellNum();
		   	System.out.println(colCount);
		   	Object data[][]= new Object[rowCount-1][colCount];
		   	for(int i=0;i<rowCount-1;i++)
		   	{
		   		row=sh.getRow(i+1);
		   		for(int j=0;j<colCount;j++)
		   		{
		   			XSSFCell cell=row.getCell(j);
		   			data[i][j]=fr.formatCellValue(cell);
		   			System.out.println(data[i][j]);
		   		}
		   	}
		   	wb.close();
			return data;
	}
	@AfterMethod
	public void logout()
	{
		//driver.quit();
		System.out.println("Logout");
	}
	
}
