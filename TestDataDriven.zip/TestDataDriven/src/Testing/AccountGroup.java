package Testing;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AccountGroup {
	
	WebDriver driver;
	@BeforeMethod
	public void Launch() throws InterruptedException
	{
	System.setProperty("webdriver.chrome.driver", "D:\\pradeep\\candy\\chromedriver95\\chromedriver_win32\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	driver.get("https://200.200.200.203/SiteMinder/");
	driver.manage().window().maximize();
	driver.manage().deleteAllCookies();
	driver.findElement(By.id("details-button")).click();
	driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
	driver.findElement(By.name("username")).sendKeys("adminuser");
	driver.findElement(By.name("password")).sendKeys("Volpay@300");
	driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	Thread.sleep(5000);
	driver.findElement(By.xpath("//a[@title='General Module' and @role='button']")).click();
	Thread.sleep(5000);
	}
	@Test(dataProvider = "Login")
	public void Workorder(String AccountGroupCode, String AccountGroupName, String Description, String AccountGroupUsage,
	String PartyCode, String AccountNo, String Status, String EffectiveFromDate,
	String EffectiveTillDate) throws InterruptedException
	{
	driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')])[2]")).click();
	driver.findElement(By.id("menu_AccountGroup")).click();
	driver.switchTo().frame(0);
	driver.findElement(By.xpath("//button[@title='Add New' and @class='btn-trans viewbtn']")).click();
	driver.findElement(By.xpath("//input[@name='AccountGroupCode' and @id='Account Group Code']")).sendKeys(AccountGroupCode);
	driver.findElement(By.xpath("//input[@name='AccountGroupName' and @id='Account Group Name']")).sendKeys(AccountGroupName);
	driver.findElement(By.xpath("//input[@name='Description' and @id='Description']")).sendKeys(Description);
	System.out.println("Successfully WSA");

	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Account Group Usage-container']")).click();
	Thread.sleep(5000);
	WebElement wsa = driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Account Group Usage-results']"));
	Thread.sleep(5000);
	wsa.sendKeys(AccountGroupUsage);
	//Thread.sleep(5000);
	wsa.sendKeys(Keys.ENTER);
	Thread.sleep(2000);

	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Party Code-container']")).click();
	Thread.sleep(5000);
	WebElement wsa1 = driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Party Code-results']"));
	Thread.sleep(5000);
	wsa1.sendKeys(PartyCode);
	//Thread.sleep(5000);
	wsa1.sendKeys(Keys.ENTER);
	Thread.sleep(2000);

	driver.findElement(By.xpath("//span[@class='select2-selection select2-selection--multiple' and @role='combobox']")).click();
	//Thread.sleep(5000);
	WebElement wsa2 = driver.findElement(By.xpath("//input[@class='select2-search__field' and @role='searchbox']"));
	Thread.sleep(5000);
	wsa2.sendKeys(AccountNo);
	Thread.sleep(5000);
	wsa2.sendKeys(Keys.ENTER);
	//Thread.sleep(2000);
	// driver.switchTo().frame(0);
	driver.findElement(By.xpath("//button[@class='btn btn-success btnStyle pull-right']")).click();
	/*
	Thread.sleep(5000);
	//driver.findElement(By.xpath("//span[@class='select2-selection select2-selection--multiple' and @role='combobox']")).click();
	//Thread.sleep(5000);
	WebElement wsa6 = driver.findElement(By.xpath("//input[@class='select2-search__field' and @role='searchbox']"));
	Thread.sleep(5000);
	wsa6.sendKeys(AccountNo);
	Thread.sleep(5000);
	wsa6.sendKeys(Keys.ENTER);
	//Thread.sleep(2000);
	// driver.switchTo().frame(0);
	driver.findElement(By.xpath("//button[@class='btn btn-success btnStyle pull-right']")).click();
	*/

	/* WebElement wsa4 = driver.findElement(By.xpath("//span[@class='select2-selection select2-selection--multiple' and @role='combobox']"));
	//wsa2.click();
	//WebElement wsa2 = driver.findElement(By.xpath("//input[@class='select2-search__field' and @role='searchbox']"));
	Thread.sleep(5000);
	wsa4.sendKeys("3333333");
	Thread.sleep(5000);
	wsa4.sendKeys(Keys.ENTER);
	Thread.sleep(2000);
	WebElement wsa5 = driver.findElement(By.xpath("//span[@class='select2-selection select2-selection--multiple' and @role='combobox']"));
	//wsa2.click();
	//WebElement wsa2 = driver.findElement(By.xpath("//input[@class='select2-search__field' and @role='searchbox']"));
	Thread.sleep(5000);
	wsa5.sendKeys("12323");
	Thread.sleep(5000);
	wsa5.sendKeys(Keys.ENTER);
	Thread.sleep(2000);*/


	driver.findElement(By.xpath("//span[@class='select2-selection__rendered' and @id='select2-Status-container']")).click();
	WebElement WE = driver.findElement(By.xpath("//input[@class='select2-search__field' and @aria-controls='select2-Status-results']"));
	WE.sendKeys(Status);
	WE.sendKeys(Keys.ENTER);
	Thread.sleep(2000);

	WebElement date = driver.findElement(By.xpath("//input[@name='EffectiveFromDate' and @id='Effective From Date']"));
	Thread.sleep(5000);
	date.sendKeys(EffectiveFromDate);
	//date.sendKeys(Keys.ENTER);
	Thread.sleep(2000);
	driver.findElement(By.xpath("//button[@class='btn btnStyle clr' and @tooltip='Submit']")).click();
	}
	
	@DataProvider(name="Login")
	public Object[][] getExcel() throws IOException
	{
	DataFormatter fr=new DataFormatter();
	FileInputStream fis = new FileInputStream("D:\\pradeep\\candy\\Automation_WorkOrder.xlsx");
	XSSFWorkbook wb = new XSSFWorkbook(fis);
	XSSFSheet sh = wb.getSheetAt(5);
	XSSFRow row=sh.getRow(0);
	int rowCount=sh.getPhysicalNumberOfRows();
	System.out.println(rowCount);
	int colCount=row.getLastCellNum();
	System.out.println(colCount);
	Object data[][]= new Object[rowCount-1][colCount];
	for(int i=0;i<rowCount-1;i++)
	{
	row=sh.getRow(i+1);
	for(int j=0;j<colCount;j++)
	{
	XSSFCell cell=row.getCell(j);
	data[i][j]=fr.formatCellValue(cell);
	System.out.println(data[i][j]);
	}
	}
	wb.close();
	return data;
	}
	@AfterMethod
	public void logout()
	{
	//driver.quit();
	System.out.println("Logout");
	}

	}
