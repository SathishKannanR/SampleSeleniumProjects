package Testing;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;



public class StandingInstructionProfile {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        driver.get("https://200.200.200.203/SiteMinder/");
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();        
        driver.findElement(By.id("details-button")).click();
        driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
        driver.findElement(By.className("form-control")).sendKeys("adminuser");
        driver.findElement(By.name("password")).sendKeys("Volpay@300");
        driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
        System.out.println("login successfully");
        
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//span[contains(text(),' Dashboard')])[1]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'Standing Instruction Template')]")).click();
        System.out.println("Standing Instruction Template Profile launched successfully");

        driver.switchTo().frame(0);
        //Thread.sleep(3000);
        driver.findElement(By.xpath("//button[@class='btn-trans viewbtn' and @title='Add New']")).click();
        //Thread.sleep(15000);
        System.out.println("Add new Profile launched successfully");
        
        driver.findElement(By.xpath("//input[@name='Template']")).sendKeys("Template1");
        Thread.sleep(3000);
        
        Select st = new Select(driver.findElement(By.xpath("//select[@name='Status']")));
        Thread.sleep(3000);
        st.selectByVisibleText("ACTIVE");
        
        WebElement WE1=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
        WE1.sendKeys("2021-09-30");
        WE1.sendKeys(Keys.ENTER);
        
        Select se = new Select(driver.findElement(By.xpath("//select[@name='Product']")));
        se.selectByVisibleText("CLEARING");
        
        //To Select the Message Type
        Select se1 = new Select(driver.findElement(By.xpath("//select[@name='MsgTp']")));
        se1.selectByIndex(4);
        WebElement Msg=se1.getFirstSelectedOption();
        String MessageType=Msg.getText();
        System.out.println(MessageType);
        
        if (MessageType.contains("CustomerCreditTransfer"))
        {
        
        Select se2 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
        se2.selectByVisibleText("303230113(303230113)");
        
        /*WebElement WE2=driver.findElement(By.xpath("//input[@name='ValueDate']"));
        WE2.sendKeys("2021-09-29");
        WE2.sendKeys(Keys.ENTER);*/
        
        Select se3 = new Select(driver.findElement(By.xpath("//select[@name='Ccy']")));
        Thread.sleep(5000);
        se3.selectByVisibleText("USD(US)");
        

        driver.findElement(By.xpath("//input[@name='Amt']")).sendKeys("20000");
        
        //To open ordering Customer Section
        //driver.findElement(By.xpath("//span[contains(text(), 'Ordering Customer')]")).click();        
         
        Thread.sleep(3000);
        //To Open Ordering Bank Details Section
        driver.findElement(By.xpath("//span[contains(text(), 'Ordering Bank Details')]")).click();
                
        Select se4=new Select(driver.findElement(By.xpath("(//select[@name='BnfBkDtlsFinInstNm'])[2]")));
        se4.selectByVisibleText("021000018");
        
        Thread.sleep(3000);
      //To open Beneficiary Bank Details Section
        driver.findElement(By.xpath("//span[contains(text(), 'Beneficiary Bank Details ')]")).click(); 
        
        //Beneficiary Bank Details Section
        Select se5 = new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsBkIdNo']")));
        Thread.sleep(3000);
        se5.selectByVisibleText("021000018");
        
        //Beneficiary Details
        Select se6 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
        se6.selectByVisibleText("303230112(303230112)");
        
        //Submit Button
        driver.findElement(By.xpath("//input[@class='btn btnStyle' and @value='Submit']")).click();
        
        String act_res=driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
        System.out.println(act_res);
        if(act_res.contains("StandingInstructionTemplate successfully added"))
		{             
            System.out.println("Template For Customer Credit Transfer has been created Successfully");
        }
        
        }
        else if(MessageType.contains("CustomerRequestForPayment"))
        {
        	 Select se2 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
             se2.selectByVisibleText("303230113(303230113)");
             
             /*WebElement WE2=driver.findElement(By.xpath("//input[@name='ValueDate']"));
             WE2.sendKeys("2021-09-29");
             WE2.sendKeys(Keys.ENTER);*/
             
             Select se3 = new Select(driver.findElement(By.xpath("//select[@name='Ccy']")));
             se3.selectByVisibleText("USD(US)");
             

             driver.findElement(By.xpath("//input[@name='Amt']")).sendKeys("20000");             
                           
            //To open Debtor Details Section
             driver.findElement(By.xpath("//span[contains(text(),'Debtor Details')]")).click();
             
             //To add Debtor Account Number
             Select se4=new Select(driver.findElement(By.xpath("//select[@name='DbtrDtlsAccNo']")));
             se4.selectByVisibleText("303230112(303230112)");
             
             Thread.sleep(3000);
           //To open Debtor Bank Details Section
             driver.findElement(By.xpath("//span[contains(text(),'Debtor Bank Details ')]")).click();
             
             Select se5=new Select(driver.findElement(By.xpath("(//select[@name='BnfBkDtlsFinInstNm'])[2]")));
        	 se5.selectByVisibleText("021000018");
        	 
        	 Thread.sleep(3000);
        	//To open Beneficiary Bank Details
        	 driver.findElement(By.xpath("//span[contains(text(),'Beneficiary Bank Details')]")).click();
        	 
        	 Select se6=new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsBkIdNo']")));
        	 se6.selectByVisibleText("211001234");
        	 
        	 Thread.sleep(3000);
        	 //Submit Button
             driver.findElement(By.xpath("(//input[@class='btn btnStyle'])[1]")).submit();
             
             String act_res=driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
            System.out.println(act_res);
            
            if(act_res.contains("StandingInstructionTemplate successfully added"))
            		{             
             System.out.println("Template For Customer Request For Payment has been created Successfully");
        }
      
   
	}
        else if(MessageType.contains("BankRequestForPayment"))
        {
        	 Select se2 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
             se2.selectByVisibleText("303230113(303230113)");
             
             /*WebElement WE2=driver.findElement(By.xpath("//input[@name='ValueDate']"));
             WE2.sendKeys("2021-09-29");
             WE2.sendKeys(Keys.ENTER);*/
             
             Select se3 = new Select(driver.findElement(By.xpath("//select[@name='Ccy']")));
             se3.selectByVisibleText("USD(US)");
             

             driver.findElement(By.xpath("//input[@name='Amt']")).sendKeys("20000");             
                           
            //To open Debtor Details Section
             driver.findElement(By.xpath("//span[contains(text(),'Debtor Details')]")).click();
             
             //To add Debtor Account Number
             Select se4=new Select(driver.findElement(By.xpath("//select[@name='DbtrDtlsAccNo']")));
             se4.selectByVisibleText("303230112(303230112)");
             
             Thread.sleep(3000);
           //To open Debtor Bank Details Section
             driver.findElement(By.xpath("//span[contains(text(),'Debtor Bank Details ')]")).click();
             
             Select se5=new Select(driver.findElement(By.xpath("(//select[@name='BnfBkDtlsFinInstNm'])[2]")));
        	 se5.selectByVisibleText("021000018");
        	 
        	 Thread.sleep(3000);
        	//To open Beneficiary Bank Details
        	 driver.findElement(By.xpath("//span[contains(text(),'Beneficiary Bank Details')]")).click();
        	 
        	 Select se6=new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsBkIdNo']")));
        	 se6.selectByVisibleText("211001234");
        	 
        	 Thread.sleep(3000);
        	 //Submit Button
             driver.findElement(By.xpath("(//input[@class='btn btnStyle'])[1]")).submit();
             
             String act_res=driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
            System.out.println(act_res);
            
            if(act_res.contains("StandingInstructionTemplate successfully added"))
            		{             
             System.out.println("Template For Bank Request For Payment has been created Successfully");	
        }
        }
        
	}
}
