package Testing;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SITemplate {
	
WebDriver driver;
	
	@BeforeMethod
	public void Launch() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathishkannan.r\\Automation\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://200.200.200.203/SiteMinder/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to 200.200.200.203 (unsafe)")).click();
		WebElement txt= driver.findElement(By.className("form-control"));
		txt.clear();
		txt.sendKeys("adminuser");
		WebElement txt1= driver.findElement(By.name("password"));
		txt1.clear();
		txt1.sendKeys("Volpay@300");
		//Thread.sleep(3000);
		driver.findElement(By.cssSelector("body > div.container > div > div > div > div.panel-body > form > fieldset > input")).click();
	    //Thread.sleep(5000);
	}
	
	@Test(dataProvider = "Login")
	public void StandingIInstructionTemplate(String TemplateName, String EntityStatusCode, String EffectiveFrom,
			String ProductsSupported,
			String MessageType, String AccountNumber, String ValueDate, String Currency, String Amount, 
			 String AccountNumber1, String BankIdentificationCode, String BankIdentificationNumber1,
			String AccountNumber2, String BankIdentificationNumber2) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//span[contains(text(),' Dashboard')])[1]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),' Standing Instruction Module')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//span[contains(text(),' Standing Instruction')]) [2]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'Standing Instruction Template')]")).click();
        System.out.println("Standing Instruction Template Profile launched successfully");

        driver.switchTo().frame(0);
        //Thread.sleep(3000);
        driver.findElement(By.xpath("//button[@class='btn-trans viewbtn' and @title='Add New']")).click();
        //Thread.sleep(15000);
        System.out.println("Add new Profile launched successfully");
        
        driver.findElement(By.xpath("//input[@name='Template']")).sendKeys(TemplateName);
        Thread.sleep(3000);
        
        Select st = new Select(driver.findElement(By.xpath("//select[@name='Status']")));
        Thread.sleep(3000);
        st.selectByVisibleText(EntityStatusCode);
        
        WebElement WE1=driver.findElement(By.xpath("//input[@name='EffectiveFromDate']"));
        WE1.sendKeys(EffectiveFrom);
        WE1.sendKeys(Keys.ENTER);
        
        Select se = new Select(driver.findElement(By.xpath("//select[@name='Product']")));
        se.selectByVisibleText(ProductsSupported);
        
        //To Select the Message Type
        Select se1 = new Select(driver.findElement(By.xpath("//select[@name='MsgTp']")));
        //se1.selectByIndex(4);
        se1.selectByVisibleText(MessageType);
        WebElement Msg=se1.getFirstSelectedOption();
        String MessageTpe=Msg.getText();
        System.out.println(MessageTpe);
        Thread.sleep(3000);
        try {
        if (MessageTpe.contains("CustomerCreditTransfer"))
        {
        Thread.sleep(3000);
        Select se2 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
        se2.selectByValue(AccountNumber);
        
        /*WebElement WE2=driver.findElement(By.xpath("//input[@name='ValueDate']"));
        WE2.sendKeys("2021-09-29");
        WE2.sendKeys(Keys.ENTER);*/
        
        Select se3 = new Select(driver.findElement(By.xpath("//select[@name='Ccy']")));
        Thread.sleep(5000);
        se3.selectByValue(Currency);
        

        driver.findElement(By.xpath("//input[@name='Amt']")).sendKeys(Amount);
        
        //To open ordering Customer Section
        //driver.findElement(By.xpath("//span[contains(text(), 'Ordering Customer')]")).click();        
         
        Thread.sleep(3000);
        //To Open Ordering Bank Details Section
        driver.findElement(By.xpath("//span[contains(text(), 'Ordering Bank Details')]")).click();
                
        Select se4=new Select(driver.findElement(By.xpath("(//select[@name='BnfBkDtlsFinInstNm'])[2]")));
        se4.selectByValue(BankIdentificationCode);
        
        Thread.sleep(3000);
      //To open Beneficiary Bank Details Section
        driver.findElement(By.xpath("//span[contains(text(), 'Beneficiary Bank Details ')]")).click(); 
        
        //Beneficiary Bank Details Section
        Select se5 = new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsBkIdNo']")));
        Thread.sleep(3000);
        se5.selectByValue(BankIdentificationNumber1);
        
        //Beneficiary Details
        Select se6 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
        se6.selectByValue(AccountNumber2);
        
        //Submit Button
        driver.findElement(By.xpath("//input[@class='btn btnStyle' and @value='Submit']")).click();
        
        String act_res=driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
        System.out.println(act_res);
        if(act_res.contains("StandingInstructionTemplate successfully added"))
		{             
            System.out.println("Template For Customer Credit Transfer has been created Successfully");
        }
        
        }
        else if(MessageType.contains("CustomerRequestForPayment"))
        {
        	 Select se2 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
             se2.selectByValue(AccountNumber);
             
             /*WebElement WE2=driver.findElement(By.xpath("//input[@name='ValueDate']"));
             WE2.sendKeys("2021-09-29");
             WE2.sendKeys(Keys.ENTER);*/
             
             Select se3 = new Select(driver.findElement(By.xpath("//select[@name='Ccy']")));
             se3.selectByValue(Currency);
             

             driver.findElement(By.xpath("//input[@name='Amt']")).sendKeys(Amount);             
                           
            //To open Debtor Details Section
             driver.findElement(By.xpath("//span[contains(text(),'Debtor Details')]")).click();
             
             //To add Debtor Account Number
             Select se4=new Select(driver.findElement(By.xpath("//select[@name='DbtrDtlsAccNo']")));
             se4.selectByValue(AccountNumber1);
             
             Thread.sleep(3000);
           //To open Debtor Bank Details Section
             driver.findElement(By.xpath("//span[contains(text(),'Debtor Bank Details ')]")).click();
             
             Select se5=new Select(driver.findElement(By.xpath("(//select[@name='BnfBkDtlsFinInstNm'])[2]")));
        	 se5.selectByValue(BankIdentificationCode);
        	 
        	 Thread.sleep(3000);
        	//To open Beneficiary Bank Details
        	 driver.findElement(By.xpath("//span[contains(text(),'Beneficiary Bank Details')]")).click();
        	 
        	 Select se6=new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsBkIdNo']")));
        	 se6.selectByValue(BankIdentificationNumber1);
        	 
        	 Thread.sleep(3000);
        	 //Submit Button
             driver.findElement(By.xpath("(//input[@class='btn btnStyle'])[1]")).submit();
             
             String act_res=driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
            System.out.println(act_res);
            
            if(act_res.contains("StandingInstructionTemplate successfully added"))
            		{             
             System.out.println("Template For Customer Request For Payment has been created Successfully");
        }
      
   
	}
        else if(MessageType.contains("BankRequestForPayment"))
        {
        	 Select se2 = new Select(driver.findElement(By.xpath("(//select[@name='AccNo'])[1]")));
             se2.selectByValue("303230113(303230113)");
             
             /*WebElement WE2=driver.findElement(By.xpath("//input[@name='ValueDate']"));
             WE2.sendKeys("2021-09-29");
             WE2.sendKeys(Keys.ENTER);*/
             
             Select se3 = new Select(driver.findElement(By.xpath("//select[@name='Ccy']")));
             se3.selectByValue("USD(US)");
             

             driver.findElement(By.xpath("//input[@name='Amt']")).sendKeys("20000");             
                           
            //To open Debtor Details Section
             driver.findElement(By.xpath("//span[contains(text(),'Debtor Details')]")).click();
             
             //To add Debtor Account Number
             Select se4=new Select(driver.findElement(By.xpath("//select[@name='DbtrDtlsAccNo']")));
             se4.selectByValue("303230112(303230112)");
             
             Thread.sleep(3000);
           //To open Debtor Bank Details Section
             driver.findElement(By.xpath("//span[contains(text(),'Debtor Bank Details ')]")).click();
             
             Select se5=new Select(driver.findElement(By.xpath("(//select[@name='BnfBkDtlsFinInstNm'])[2]")));
        	 se5.selectByValue("021000018");
        	 
        	 Thread.sleep(3000);
        	//To open Beneficiary Bank Details
        	 driver.findElement(By.xpath("//span[contains(text(),'Beneficiary Bank Details')]")).click();
        	 
        	 Select se6=new Select(driver.findElement(By.xpath("//select[@name='BnfBkDtlsBkIdNo']")));
        	 se6.selectByVisibleText("211001234");
        	 
        	 Thread.sleep(3000);
        	 //Submit Button
             driver.findElement(By.xpath("(//input[@class='btn btnStyle'])[1]")).submit();
             
             String act_res=driver.findElement(By.xpath("//div[@ng-repeat='alert in alerts']")).getText();
            System.out.println(act_res);
            
            if(act_res.contains("StandingInstructionTemplate successfully added"))
            		{             
             System.out.println("Template For Bank Request For Payment has been created Successfully");	
        }
        }
        } catch (Exception e) {
        	System.out.println(e.getMessage());



        	}
        
	}
	@DataProvider(name="Login")
	public Object[][] getExcel() throws IOException
	{
		DataFormatter fr=new DataFormatter();
		FileInputStream fis = new FileInputStream("C:\\Users\\sathishkannan.r\\Automation\\TestDataDriven\\WorkorderData1.xlsx");
		   	XSSFWorkbook wb = new XSSFWorkbook(fis);
		   	XSSFSheet sh = wb.getSheetAt(7);
		   	XSSFRow row=sh.getRow(0);
		   	int rowCount=sh.getPhysicalNumberOfRows();
		   	System.out.println(rowCount);
		   	int colCount=row.getLastCellNum();
		   	System.out.println(colCount);
		   	Object data[][]= new Object[rowCount-1][colCount];
		   	for(int i=0;i<rowCount-1;i++)
		   	{
		   		row=sh.getRow(i+1);
		   		for(int j=0;j<colCount;j++)
		   		{
		   			XSSFCell cell=row.getCell(j);
		   			data[i][j]=fr.formatCellValue(cell);
		   			System.out.println(data[i][j]);
		   		}
		   	}
		   	wb.close();
			return data;
	}
	@AfterMethod
	public void logout()
	{
		//driver.quit();
		System.out.println("Logout");
	}

}
